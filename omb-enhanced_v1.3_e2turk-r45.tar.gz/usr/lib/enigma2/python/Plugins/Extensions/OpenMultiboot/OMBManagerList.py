from __future__ import print_function
from __future__ import absolute_import

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Screens.Standby import TryQuitMainloop

from Components.ActionMap import ActionMap
from Components.Button import Button
from Components.ConfigList import ConfigListScreen
from Components.Pixmap import Pixmap
from Components.Sources.List import List
from Components.Label import Label
from Components.config import getConfigListEntry, config, ConfigYesNo, NoSave

from .OMBManagerInstall import OMBEnhancedInstall, OMB_RM_BIN, BRANDING
from .OMBManagerAbout import OMBEnhancedAbout
from .OMBManagerCommon import OMB_DATA_DIR, OMB_UPLOAD_DIR
from .OMBManagerLocale import _
from .OMBList import OMBList
from .OMBConfig import omb_legacy

from .BoxConfig import BoxConfig

from enigma import eTimer, getDesktop

def getDS():
	s = getDesktop(0).size()
	return (s.width(), s.height())
def isFHD():
	desktopSize = getDS()
	return desktopSize[0] == 1920
def isHD():
	desktopSize = getDS()
	return desktopSize[0] >= 1280 and desktopSize[0] < 1920
def isUHD():
	desktopSize = getDS()
	return desktopSize[0] >= 1920 and desktopSize[0] < 3840
def isTR():
	try:
		dil = ""
		ara = open("/etc/enigma2/settings", "r")
		bul = "config.osd.language=tr_TR"
		bak = ara.read().find(bul)
		if bak != -1:
			dil = "OK"
		else:
			dil = "NO"
		return dil
		ara.close()
	except:
		pass

import os
from subprocess import Popen, PIPE, STDOUT

class OMBEnhancedList(Screen):
	if isFHD():
		skin = """
<screen position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#ff111111">
	<widget source="Title" render="Label" position="87,54" size="788,75" font="sagoe;51" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" noWrap="1" transparent="1" />
	<widget name="label3" position="105,180" size="500,45" font="osans;30" halign="left" valign="center" foregroundColor="#00E2E2E2" backgroundColor="#1A0F0F0F" zPosition="1" transparent="1" />
	<eLabel position="105,240" size="1050,2" backgroundColor="#00E2E2E2" />
	<widget source="list" render="Listbox" position="105,270" size="1050,405" itemHeight="45" font="osans;30" scrollbarMode="showOnDemand" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" foregroundColorSelected="#00FFFFF" backgroundColorSelected="#1A27408B" scrollbarSliderBorderWidth="1" scrollbarWidth="8" scrollbarSliderForegroundColor="#00FFFFFF" scrollbarSliderBorderColor="#0027408B" enableWrapAround="1" transparent="1">
		<convert type="StringList" />
	</widget>
	<eLabel position="105,735" size="1050,2" backgroundColor="#00BDBDBD" />
	<widget name="label1" position="114,750" size="405,45" font="osans;30" halign="left" valign="center" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" zPosition="1" transparent="1" />
	<widget name="label2" position="510,750" size="636,45" font="osans;30" halign="right" valign="center" foregroundColor="#00A4C400" backgroundColor="#1A0F0F0F" zPosition="1" transparent="1" />
	<eLabel position="105,810" size="1050,2" backgroundColor="#00BDBDBD" />
	<ePixmap position="1350,300" size="384,177" zPosition="5" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/ico_ombe_FHD.png" transparent="1" alphatest="blend" />
	<ePixmap position="1425,900" size="122,60" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/bt_menu_FHD.png" transparent="1" alphatest="blend" />
	<ePixmap position="1568,900" size="122,60" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/bt_ok_FHD.png" transparent="1" alphatest="blend" />
	<ePixmap position="1710,900" size="122,60" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/bt_exit_FHD.png" transparent="1" alphatest="blend" />
	<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/btc_red_FHD.png" position="53,953" size="45,60" alphatest="blend" />
	<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/btc_green_FHD.png" position="327,953" size="45,60" alphatest="blend" />
	<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/btc_yellow_FHD.png" position="602,953" size="45,60" alphatest="blend" />
	<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/btc_blue_FHD.png" position="876,953" size="45,60" alphatest="blend" />
	<widget name="key_red" position="105,957" size="255,45" noWrap="1" zPosition="1" valign="center" font="buton;30" halign="left" backgroundColor="#1A0F0F0F" foregroundColor="#00FFFFFF" transparent="1" />
	<widget name="key_green" position="380,957" size="255,45" noWrap="1" zPosition="1" valign="center" font="buton;30" halign="left" backgroundColor="#1A0F0F0F" foregroundColor="#00FFFFFF" transparent="1" />
	<widget name="key_yellow" position="654,957" size="255,45" noWrap="1" zPosition="1" valign="center" font="buton;30" halign="left" backgroundColor="#1A0F0F0F" foregroundColor="#00FFFFFF" transparent="1" />
	<widget name="key_blue" position="929,957" size="270,45" noWrap="1" zPosition="1" valign="center" font="buton;30" halign="left" backgroundColor="#1A0F0F0F" foregroundColor="#00FFFFFF" transparent="1" />
	<eLabel position="60,38" zPosition="-10" size="1133,975" backgroundColor="#1A0F0F0F" name="layer1" />
	<eLabel position="1193,90" zPosition="-10" size="668,870" backgroundColor="#1A27408B" name="layer2" />
	<widget source="global.CurrentTime" render="Label" position="978,45" size="210,90" font="sagoe;75" noWrap="1" halign="center" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Default</convert></widget>
	<widget source="global.CurrentTime" render="Label" position="768,45" size="210,41" font="sagoe;24" noWrap="1" halign="right" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Format:%A</convert></widget>
	<widget source="global.CurrentTime" render="Label" position="768,81" size="210,41" font="sagoe;24" noWrap="1" halign="right" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Format:%e. %b.</convert></widget>
</screen>
"""
	elif isUHD():
		skin = """
<screen position="0,0" size="3840,2160" flags="wfNoBorder" backgroundColor="#ff111111">
	<widget source="Title" render="Label" position="174,108" size="1575,150" font="sagoe;102" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" noWrap="1" transparent="1" />
	<widget name="label3" position="210,360" size="990,30" font="osans;60" halign="left" valign="center" foregroundColor="#00E2E2E2" backgroundColor="#1A0F0F0F" zPosition="1" transparent="1" />
	<eLabel position="210,480" size="700,3" backgroundColor="#00E2E2E2" />
	<widget source="list" render="Listbox" position="210,540" size="2100,810" itemHeight="90" font="osans;60" scrollbarMode="showOnDemand" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" foregroundColorSelected="#00FFFFF" backgroundColorSelected="#1A27408B" scrollbarSliderBorderWidth="1" scrollbarWidth="8" scrollbarSliderForegroundColor="#00FFFFFF" scrollbarSliderBorderColor="#0027408B" enableWrapAround="1" transparent="1">
		<convert type="StringList" />
	</widget>
	<eLabel position="210,360" size="2100,3" backgroundColor="#00BDBDBD" />
	<widget name="label1" position="228,1500" size="810,90" font="osans;60" halign="left" valign="center" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" zPosition="1" transparent="1" />
	<widget name="label2" position="1020,1500" size="1272,90" font="osans;60" halign="right" valign="center" foregroundColor="#00A4C400" backgroundColor="#1A0F0F0F" zPosition="1" transparent="1" />
	<eLabel position="210,480" size="2100,3" backgroundColor="#00BDBDBD" />
	<ePixmap position="2700,600" size="768,354" zPosition="5" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/ico_ombe_UHD.png" transparent="1" alphatest="blend" />
	<ePixmap position="2850,1800" size="243,120" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/bt_menu_UHD.png" transparent="1" alphatest="blend" />
	<ePixmap position="3135,1800" size="243,120" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/bt_ok_UHD.png" transparent="1" alphatest="blend" />
	<ePixmap position="3420,1800" size="243,120" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/bt_exit_UHD.png" transparent="1" alphatest="blend" />
	<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/btc_red_UHD.png" position="105,1905" size="90,120" alphatest="blend" />
	<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/btc_green_UHD.png" position="654,1905" size="90,120" alphatest="blend" />
	<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/btc_yellow_UHD.png" position="1203,1905" size="90,120" alphatest="blend" />
	<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/btc_blue_UHD.png" position="1752,1905" size="90,120" alphatest="blend" />
	<widget name="key_red" position="210,1914" size="510,90" noWrap="1" zPosition="1" valign="center" font="buton;60" halign="left" backgroundColor="#1A0F0F0F" foregroundColor="#00FFFFFF" transparent="1" />
	<widget name="key_green" position="759,1914" size="510,90" noWrap="1" zPosition="1" valign="center" font="buton;60" halign="left" backgroundColor="#1A0F0F0F" foregroundColor="#00FFFFFF" transparent="1" />
	<widget name="key_yellow" position="1308,1914" size="510,90" noWrap="1" zPosition="1" valign="center" font="buton;60" halign="left" backgroundColor="#1A0F0F0F" foregroundColor="#00FFFFFF" transparent="1" />
	<widget name="key_blue" position="1857,1914" size="540,90" noWrap="1" zPosition="1" valign="center" font="buton;60" halign="left" backgroundColor="#1A0F0F0F" foregroundColor="#00FFFFFF" transparent="1" />
	<eLabel position="120,75" zPosition="-10" size="2265,1950" backgroundColor="#1A0F0F0F" name="layer1" />
	<eLabel position="2385,180" zPosition="-10" size="1335,1740" backgroundColor="#1A27408B" name="layer2" />
	<widget source="global.CurrentTime" render="Label" position="1956,90" size="420,180" font="sagoe;150" noWrap="1" halign="center" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Default</convert></widget>
	<widget source="global.CurrentTime" render="Label" position="1536,90" size="420,81" font="sagoe;48" noWrap="1" halign="right" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Format:%A</convert></widget>
	<widget source="global.CurrentTime" render="Label" position="1536,162" size="420,81" font="sagoe;48" noWrap="1" halign="right" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Format:%e. %b.</convert></widget>
</screen>
"""
	else:
		skin = """
<screen position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="#ff111111">
	<widget source="Title" render="Label" position="58,36" size="525,50" font="sagoe;34" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" noWrap="1" transparent="1" />
	<widget name="label3" position="70,120" size="330,30" font="osans;20" halign="left" valign="center" foregroundColor="#00E2E2E2" backgroundColor="#1A0F0F0F" zPosition="1" transparent="1" />
	<eLabel position="70,160" size="700,1" backgroundColor="#00E2E2E2" />
	<widget source="list" render="Listbox" position="70,180" size="700,270" itemHeight="30" font="osans;20" scrollbarMode="showOnDemand" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" foregroundColorSelected="#00FFFFF" backgroundColorSelected="#1A27408B" scrollbarSliderBorderWidth="1" scrollbarWidth="8" scrollbarSliderForegroundColor="#00FFFFFF" scrollbarSliderBorderColor="#0027408B" enableWrapAround="1" transparent="1">
		<convert type="StringList" />
	</widget>
	<eLabel position="70,490" size="700,1" backgroundColor="#00BDBDBD" />	
	<widget name="label1" position="76,500" size="270,30" font="osans;20" halign="left" valign="center" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" zPosition="1" transparent="1" />
	<widget name="label2" position="340,500" size="424,30" font="osans;20" halign="right" valign="center" foregroundColor="#00A4C400" backgroundColor="#1A0F0F0F" zPosition="1" transparent="1" />
	<eLabel position="70,540" size="700,1" backgroundColor="#00BDBDBD" />
	<ePixmap position="900,200" size="256,118" zPosition="5" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/ico_ombe.png" transparent="1" alphatest="blend" />
	<ePixmap position="950,600" size="81,40" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/bt_menu.png" transparent="1" alphatest="blend" />
	<ePixmap position="1045,600" size="81,40" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/bt_ok.png" transparent="1" alphatest="blend" />
	<ePixmap position="1140,600" size="81,40" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/bt_exit.png" transparent="1" alphatest="blend" />
	<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/btc_red.png" position="35,635" size="30,40" alphatest="blend" />
	<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/btc_green.png" position="218,635" size="30,40" alphatest="blend" />
	<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/btc_yellow.png" position="401,635" size="30,40" alphatest="blend" />
	<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/btc_blue.png" position="584,635" size="30,40" alphatest="blend" />
	<widget name="key_red" position="70,638" size="170,30" noWrap="1" zPosition="1" valign="center" font="buton;20" halign="left" backgroundColor="#1A0F0F0F" foregroundColor="#00FFFFFF" transparent="1" />
	<widget name="key_green" position="253,638" size="170,30" noWrap="1" zPosition="1" valign="center" font="buton;20" halign="left" backgroundColor="#1A0F0F0F" foregroundColor="#00FFFFFF" transparent="1" />
	<widget name="key_yellow" position="436,638" size="170,30" noWrap="1" zPosition="1" valign="center" font="buton;20" halign="left" backgroundColor="#1A0F0F0F" foregroundColor="#00FFFFFF" transparent="1" />
	<widget name="key_blue" position="619,638" size="180,30" noWrap="1" zPosition="1" valign="center" font="buton;20" halign="left" backgroundColor="#1A0F0F0F" foregroundColor="#00FFFFFF" transparent="1" />
	<eLabel position="40,25" zPosition="-10" size="755,650" backgroundColor="#1A0F0F0F" name="layer1" />
	<eLabel position="795,60" zPosition="-10" size="445,580" backgroundColor="#1A27408B" name="layer2" />
	<widget source="global.CurrentTime" render="Label" position="652,30" size="140,60" font="sagoe;50" noWrap="1" halign="center" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Default</convert></widget>
	<widget source="global.CurrentTime" render="Label" position="512,30" size="140,27" font="sagoe;16" noWrap="1" halign="right" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Format:%A</convert></widget>
	<widget source="global.CurrentTime" render="Label" position="512,54" size="140,27" font="sagoe;16" noWrap="1" halign="right" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Format:%e. %b.</convert></widget>
</screen>
"""

	def __init__(self, session, mount_point):
		Screen.__init__(self, session)
		self.setTitle("OMB Enhanced by e2TURK")
		self.session = session
		mount_point = mount_point.rstrip("/")
		self.mount_point = mount_point
		self.data_dir = mount_point + '/' + OMB_DATA_DIR
		self.upload_dir = mount_point + '/' + OMB_UPLOAD_DIR
		self.select = None
		self.dynamic_loader = None
		self.running_box_type = None
		self["label1"] = Label(_("Current Running Image:"))
		self["label2"] = Label("")
		self["label3"] = Label(_("Choose Image to Take Action"))
		self.populateImagesList()
		self["list"] = List(self.images_list)
		self["list"].onSelectionChanged.append(self.onSelectionChanged)
		self["key_red"] = Button(_('Start'))
		self["key_yellow"] = Button()
		self["key_blue"] = Button(_('Rename'))
		if BRANDING:
			self["key_green"] = Button(_('Install'))
		else:
			self["key_green"] = Button('')
		self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "MenuActions"],
		{
			"cancel": self.close,
			"red": self.KeyOk,
			"yellow": self.keyDelete,
			"green": self.keyInstall,
			"blue": self.keyRename,
			"ok": self.KeyOk,
			"menu": self.showMen
		})

	def populateImagesList(self):
		omblist = OMBList(self.mount_point)
		self["label2"].setText(omblist.currentImage())
		omblist.populateImagesList()
		self.images_list = omblist.getImagesList()
		self.images_entries = omblist.getImagesEntries()
		self.boxinfo = omblist.getBoxInfo()

	def refresh(self):
		self.populateImagesList()
		self["list"].setList(self.images_list)

	def canDeleteEntry(self, entry):
		selected = 'flash'
		try:
			selected = open(omb_legacy and self.data_dir + '/.selected' or '%s/.%s-selected' % (self.data_dir, self.boxinfo.getItem("model"))).read()
		except:
			pass

		if entry['path'] == '/' or entry['identifier'] == selected:
			return False
		return True

	def onSelectionChanged(self):
		if len(self.images_entries) == 0:
			return

		index = self["list"].getIndex()
		if index >= 0 and index < len(self.images_entries):
			entry = self.images_entries[index]
			if self.canDeleteEntry(entry):
				self["key_yellow"].setText(_('Delete'))
			else:
				self["key_yellow"].setText('')

	def KeyOk(self):
		self.select = self["list"].getIndex()
		name = self["list"].getCurrent()
		self.session.openWithCallback(self.confirmNextbootCB, MessageBox, _('Set next boot to %s ?') % name, MessageBox.TYPE_YESNO)

	def confirmNextbootCB(self, ret):
		if ret:
			image = self.images_entries[self.select]['identifier']
			print("[OMB] set nextboot to %s" % image)
			file_entry = omb_legacy and self.data_dir + '/.nextboot' or '%s/.%s-nextboot' % (self.data_dir, self.boxinfo.getItem("model"))
			f = open(file_entry, 'w')
			f.write(image)
			f.close()

			self.session.openWithCallback(self.confirmRebootCB, MessageBox, _('Do you want to reboot now ?'), MessageBox.TYPE_YESNO)

	def confirmRebootCB(self, ret):
		if ret:
			self.session.open(TryQuitMainloop, 2)

	def showMen(self):
		myoptions = [[_('Preferences'), 'preferences'], [_('About'), 'about']]
		self.session.openWithCallback(self.doshowMen, ChoiceBox, title=_("OpenMultiBoot Menu"), list=myoptions)

	def doshowMen(self, sel):
		if sel:
			if sel[1] == "preferences":
				self.session.open(OMBEnhancedPreferences, self.data_dir)
			elif sel[1] == "about":
				self.session.open(OMBEnhancedAbout)

	def keyRename(self):
		self.renameIndex = self["list"].getIndex()
		name = self["list"].getCurrent()
		if self["list"].getIndex() == 0:
			if name.endswith('(Flash)'):
				name = name[:-8]

		self.session.openWithCallback(self.renameEntryCallback, VirtualKeyBoard, title=_("Please enter new name:"), text=name)

	def renameEntryCallback(self, name):
		if name:
			renameimage = self.images_entries[self.renameIndex]

			if renameimage['identifier'] == 'flash':
				file_entry = self.data_dir + '/.label_flash'
			else:
				file_entry = self.data_dir + '/.label_' + renameimage['identifier']

			f = open(file_entry, 'w')
			f.write(name)
			f.close()
			self.refresh()

	def deleteConfirm(self, confirmed):
		if confirmed and len(self.entry_to_delete['path']) > 1:
			self.messagebox = self.session.open(MessageBox, _('Please wait while delete is in progress.'), MessageBox.TYPE_INFO, enable_input=False)
			self.timer = eTimer()
			self.timer.callback.append(self.deleteImage)
			self.timer.start(100)

	def deleteImage(self):
		self.timer.stop()
		os.system(OMB_RM_BIN + ' -rf ' + self.entry_to_delete['path'])
		os.system(OMB_RM_BIN + ' -f ' + self.entry_to_delete['kernelbin'])
		os.system(OMB_RM_BIN + ' -f ' + self.entry_to_delete['labelfile'])
		self.messagebox.close()
		self.refresh()

	def keyDelete(self):
		if len(self.images_entries) == 0:
			return

		index = self["list"].getIndex()
		if index >= 0 and index < len(self.images_entries):
			self.entry_to_delete = self.images_entries[index]
			if self.canDeleteEntry(self.entry_to_delete):
				self.session.openWithCallback(self.deleteConfirm, MessageBox, _("Do you want to delete %s?") % self.entry_to_delete['label'], MessageBox.TYPE_YESNO)

	def keyInstall(self):
		if not BRANDING:
			return
		upload_list = []
		if os.path.exists(self.upload_dir):
			for file_entry in os.listdir(self.upload_dir):
				if file_entry[0] == '.' or file_entry == 'flash.zip':
					continue

				if len(file_entry) > 4 and file_entry[-4:] == '.zip':
					upload_list.append(file_entry[:-4])

		if len(upload_list) > 0:
			self.session.openWithCallback(self.refresh, OMBEnhancedInstall, self.mount_point, upload_list)
		else:
			self.session.open(MessageBox, _("Please upload an image inside %s") % self.upload_dir, type=MessageBox.TYPE_ERROR)


class OMBEnhancedPreferences(Screen, ConfigListScreen):
	if isFHD():
		skin = """
<screen position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#ff111111">
	<widget source="Title" render="Label" position="87,54" size="788,75" font="sagoe;51" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" noWrap="1" transparent="1" />
	<widget name="info" position="105,180" size="900,45" font="osans;30" halign="left" valign="center" foregroundColor="#00E2E2E2" backgroundColor="#1A0F0F0F" zPosition="1" transparent="1" />
	<eLabel position="105,240" size="1050,2" backgroundColor="#00E2E2E2" />
	<widget name="config" position="105,270" size="1050,675" itemHeight="45" font="osans;30" scrollbarMode="showOnDemand" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" foregroundColorSelected="#00FFFFF" backgroundColorSelected="#1A27408B" scrollbarSliderBorderWidth="1" scrollbarWidth="8" scrollbarSliderForegroundColor="#00FFFFFF" scrollbarSliderBorderColor="#0027408B" enableWrapAround="1" transparent="1" />
	<ePixmap position="1350,300" size="384,177" zPosition="5" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/ico_ombe_FHD.png" transparent="1" alphatest="blend" />
	<ePixmap position="1568,900" size="122,60" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/bt_ok_FHD.png" transparent="1" alphatest="blend" />
	<ePixmap position="1710,900" size="122,60" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/bt_exit_FHD.png" transparent="1" alphatest="blend" />
	<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/btc_red_FHD.png" position="53,953" size="45,60" alphatest="blend" />
	<widget name="key_red" position="105,957" size="255,45" noWrap="1" zPosition="1" valign="center" font="buton;30" halign="left" backgroundColor="#1A0F0F0F" foregroundColor="#00FFFFFF" transparent="1" />
	<eLabel position="60,38" zPosition="-10" size="1133,975" backgroundColor="#1A0F0F0F" name="layer1" />
	<eLabel position="1193,90" zPosition="-10" size="668,870" backgroundColor="#1A27408B" name="layer2" />
	<widget source="global.CurrentTime" render="Label" position="978,45" size="210,90" font="sagoe;75" noWrap="1" halign="center" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Default</convert></widget>
	<widget source="global.CurrentTime" render="Label" position="768,45" size="210,41" font="sagoe;24" noWrap="1" halign="right" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Format:%A</convert></widget>
	<widget source="global.CurrentTime" render="Label" position="768,81" size="210,41" font="sagoe;24" noWrap="1" halign="right" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Format:%e. %b.</convert></widget>
</screen>
"""
	elif isUHD():
		skin = """
<screen position="0,0" size="3840,2160" flags="wfNoBorder" backgroundColor="#ff111111">
	<widget source="Title" render="Label" position="174,108" size="1575,150" font="sagoe;102" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" noWrap="1" transparent="1" />
	<widget name="info" position="210,360" size="1800,90" font="osans;60" halign="left" valign="center" foregroundColor="#00E2E2E2" backgroundColor="#1A0F0F0F" zPosition="1" transparent="1" />
	<eLabel position="210,480" size="2100,3" backgroundColor="#00E2E2E2" />
	<widget name="config" position="210,540" size="2100,1350" itemHeight="90" font="osans;60" scrollbarMode="showOnDemand" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" foregroundColorSelected="#00FFFFF" backgroundColorSelected="#1A27408B" scrollbarSliderBorderWidth="1" scrollbarWidth="8" scrollbarSliderForegroundColor="#00FFFFFF" scrollbarSliderBorderColor="#0027408B" enableWrapAround="1" transparent="1" />
	<ePixmap position="2700,600" size="768,354" zPosition="5" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/ico_ombe_UHD.png" transparent="1" alphatest="blend" />
	<ePixmap position="3135,1800" size="243,120" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/bt_ok_UHD.png" transparent="1" alphatest="blend" />
	<ePixmap position="3420,1800" size="243,120" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/bt_exit_UHD.png" transparent="1" alphatest="blend" />
	<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/btc_red_UHD.png" position="105,1905" size="90,120" alphatest="blend" />
	<widget name="key_red" position="210,1914" size="510,90" noWrap="1" zPosition="1" valign="center" font="buton;60" halign="left" backgroundColor="#1A0F0F0F" foregroundColor="#00FFFFFF" transparent="1" />
	<eLabel position="120,75" zPosition="-10" size="2265,1950" backgroundColor="#1A0F0F0F" name="layer1" />
	<eLabel position="2385,180" zPosition="-10" size="1335,1740" backgroundColor="#1A27408B" name="layer2" />
	<widget source="global.CurrentTime" render="Label" position="1956,90" size="420,180" font="sagoe;150" noWrap="1" halign="center" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Default</convert></widget>
	<widget source="global.CurrentTime" render="Label" position="1536,90" size="420,81" font="sagoe;48" noWrap="1" halign="right" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Format:%A</convert></widget>
	<widget source="global.CurrentTime" render="Label" position="1536,162" size="420,81" font="sagoe;48" noWrap="1" halign="right" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Format:%e. %b.</convert></widget>
</screen>
"""
	else:
		skin = """
<screen position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="#ff111111">
	<widget source="Title" render="Label" position="58,36" size="525,50" font="sagoe;34" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" noWrap="1" transparent="1" />
	<widget name="info" position="70,120" size="600,30" font="osans;20" halign="left" valign="center" foregroundColor="#00E2E2E2" backgroundColor="#1A0F0F0F" zPosition="1" transparent="1" />
	<eLabel position="70,160" size="700,1" backgroundColor="#00E2E2E2" />
	<widget name="config" position="70,180" size="700,450" itemHeight="30" font="osans;20" scrollbarMode="showOnDemand" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" foregroundColorSelected="#00FFFFF" backgroundColorSelected="#1A27408B" scrollbarSliderBorderWidth="1" scrollbarWidth="8" scrollbarSliderForegroundColor="#00FFFFFF" scrollbarSliderBorderColor="#0027408B" enableWrapAround="1" transparent="1" />
	<ePixmap position="900,200" size="256,118" zPosition="5" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/ico_ombe.png" transparent="1" alphatest="blend" />
	<ePixmap position="1045,600" size="81,40" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/bt_ok.png" transparent="1" alphatest="blend" />
	<ePixmap position="1140,600" size="81,40" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/bt_exit.png" transparent="1" alphatest="blend" />
	<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/btc_red.png" position="35,635" size="30,40" alphatest="blend" />
	<widget name="key_red" position="70,638" size="170,30" noWrap="1" zPosition="1" valign="center" font="buton;20" halign="left" backgroundColor="#1A0F0F0F" foregroundColor="#00FFFFFF" transparent="1" />
	<eLabel position="40,25" zPosition="-10" size="755,650" backgroundColor="#1A0F0F0F" name="layer1" />
	<eLabel position="795,60" zPosition="-10" size="445,580" backgroundColor="#1A27408B" name="layer2" />
	<widget source="global.CurrentTime" render="Label" position="652,30" size="140,60" font="sagoe;50" noWrap="1" halign="center" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Default</convert></widget>
	<widget source="global.CurrentTime" render="Label" position="512,30" size="140,27" font="sagoe;16" noWrap="1" halign="right" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Format:%A</convert></widget>
	<widget source="global.CurrentTime" render="Label" position="512,54" size="140,27" font="sagoe;16" noWrap="1" halign="right" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Format:%e. %b.</convert></widget>
</screen>
"""

	def __init__(self, session, data_dir):
		Screen.__init__(self, session)
		self.setTitle(_("OMB Enhanced Preferences"))
		self.data_dir = data_dir
		self.list = []
		ConfigListScreen.__init__(self, self.list)
		self['info'] = Label(_("MultiBoot Installation Options"))
		self["key_red"] = Label(_("Save"))
		self["actions"] = ActionMap(["WizardActions", "ColorActions"],
		{
			"red": self.saveConf,
			"back": self.close
		})

		self.bootmenu_enabled = NoSave(ConfigYesNo(default=True))
		if os.path.isfile(self.data_dir + '/.bootmenu.lock'):
			self.bootmenu_enabled.value = False
		self.list.append(getConfigListEntry(_("Enable Boot Menu"), self.bootmenu_enabled))

		self.cp_channels = NoSave(ConfigYesNo(default=False))
		if os.path.isfile(self.data_dir + '/.cp_channels.on'):
			self.cp_channels.value = True
		self.list.append(getConfigListEntry(_("Copy Channel List"), self.cp_channels))

		self.cp_settings = NoSave(ConfigYesNo(default=False))
		if os.path.isfile(self.data_dir + '/.cp_settings.on'):
			self.cp_settings.value = True
		self.list.append(getConfigListEntry(_("Copy System Settings"), self.cp_settings))

		self.cp_network = NoSave(ConfigYesNo(default=False))
		if os.path.isfile(self.data_dir + '/.cp_network.on'):
			self.cp_network.value = True
		self.list.append(getConfigListEntry(_("Copy Network Settings"), self.cp_network))

		self.cp_sysplug = NoSave(ConfigYesNo(default=False))
		if os.path.isfile(self.data_dir + '/.cp_sysplug.on'):
			self.cp_sysplug.value = True
		self.list.append(getConfigListEntry(_("Copy System Plugins"), self.cp_sysplug))

		self.cp_cimodul = NoSave(ConfigYesNo(default=False))
		if os.path.isfile(self.data_dir + '/.cp_cimodul.on'):
			self.cp_cimodul.value = True
		self.list.append(getConfigListEntry(_("Copy CI Module Settings"), self.cp_cimodul))

		self.cp_softcam = NoSave(ConfigYesNo(default=False))
		if os.path.isfile(self.data_dir + '/.cp_softcam.on'):
			self.cp_softcam.value = True
		self.list.append(getConfigListEntry(_("Copy Softcam Configs"), self.cp_softcam))

		self.cp_youtube = NoSave(ConfigYesNo(default=False))
		if os.path.isfile(self.data_dir + '/.cp_youtube.on'):
			self.cp_youtube.value = True
		self.list.append(getConfigListEntry(_("Copy YouTube Plugin Settings"), self.cp_youtube))

		self.cp_subssup = NoSave(ConfigYesNo(default=False))
		if os.path.isfile(self.data_dir + '/.cp_subssup.on'):
			self.cp_subssup.value = True
		self.list.append(getConfigListEntry(_("Copy SubsSupport Plugin Settings"), self.cp_subssup))

		self.cp_turkvod = NoSave(ConfigYesNo(default=False))
		if os.path.isfile(self.data_dir + '/.cp_turkvod.on'):
			self.cp_turkvod.value = True
		self.list.append(getConfigListEntry(_("Copy TurkVOD Plugin Settings"), self.cp_turkvod))

		self.cp_iptvplyr = NoSave(ConfigYesNo(default=False))
		if os.path.isfile(self.data_dir + '/.cp_iptvplyr.on'):
			self.cp_iptvplyr.value = True
		self.list.append(getConfigListEntry(_("Copy IPTVPlayer Plugin Settings"), self.cp_iptvplyr))


		self.cp_bologo = NoSave(ConfigYesNo(default=False))
		if os.path.isfile(self.data_dir + '/.cp_bologo.on'):
			self.cp_bologo.value = True
		self.list.append(getConfigListEntry(_("Use Custom Bootlogo"), self.cp_bologo))


		if isTR() == "OK":
			self.cp_trlang = NoSave(ConfigYesNo(default=False))
			if os.path.isfile(self.data_dir + '/.cp_trlang.on'):
				self.cp_trlang.value = True
			self.list.append(getConfigListEntry(_("Let Image Start in Turkish Language"), self.cp_trlang))


		self["config"].list = self.list
		self["config"].l.setList(self.list)

	def saveConf(self):
		if self.bootmenu_enabled.value == True:
			if os.path.isfile(self.data_dir + '/.bootmenu.lock'):
				os.remove(self.data_dir + '/.bootmenu.lock')
		else:
			if not os.path.isfile(self.data_dir + '/.bootmenu.lock'):
				CM = "touch " + self.data_dir + '/.bootmenu.lock'
				os.system(CM)

		if self.cp_channels.value == False:
			if os.path.isfile(self.data_dir + '/.cp_channels.on'):
				os.remove(self.data_dir + '/.cp_channels.on')
		else:
			if not os.path.isfile(self.data_dir + '/.cp_channels.on'):
				CM = "touch " + self.data_dir + '/.cp_channels.on'
				os.system(CM)

		if self.cp_settings.value == False:
			if os.path.isfile(self.data_dir + '/.cp_settings.on'):
				os.remove(self.data_dir + '/.cp_settings.on')
		else:
			if not os.path.isfile(self.data_dir + '/.cp_settings.on'):
				CM = "touch " + self.data_dir + '/.cp_settings.on'
				os.system(CM)

		if self.cp_network.value == False:
			if os.path.isfile(self.data_dir + '/.cp_network.on'):
				os.remove(self.data_dir + '/.cp_network.on')
		else:
			if not os.path.isfile(self.data_dir + '/.cp_network.on'):
				CM = "touch " + self.data_dir + '/.cp_network.on'
				os.system(CM)

		if self.cp_sysplug.value == False:
			if os.path.isfile(self.data_dir + '/.cp_sysplug.on'):
				os.remove(self.data_dir + '/.cp_sysplug.on')
		else:
			if not os.path.isfile(self.data_dir + '/.cp_sysplug.on'):
				CM = "touch " + self.data_dir + '/.cp_sysplug.on'
				os.system(CM)

		if self.cp_cimodul.value == False:
			if os.path.isfile(self.data_dir + '/.cp_cimodul.on'):
				os.remove(self.data_dir + '/.cp_cimodul.on')
		else:
			if not os.path.isfile(self.data_dir + '/.cp_cimodul.on'):
				CM = "touch " + self.data_dir + '/.cp_cimodul.on'
				os.system(CM)

		if self.cp_softcam.value == False:
			if os.path.isfile(self.data_dir + '/.cp_softcam.on'):
				os.remove(self.data_dir + '/.cp_softcam.on')
		else:
			if not os.path.isfile(self.data_dir + '/.cp_softcam.on'):
				CM = "touch " + self.data_dir + '/.cp_softcam.on'
				os.system(CM)

		if self.cp_youtube.value == False:
			if os.path.isfile(self.data_dir + '/.cp_youtube.on'):
				os.remove(self.data_dir + '/.cp_youtube.on')
		else:
			if not os.path.isfile(self.data_dir + '/.cp_youtube.on'):
				CM = "touch " + self.data_dir + '/.cp_youtube.on'
				os.system(CM)

		if self.cp_subssup.value == False:
			if os.path.isfile(self.data_dir + '/.cp_subssup.on'):
				os.remove(self.data_dir + '/.cp_subssup.on')
		else:
			if not os.path.isfile(self.data_dir + '/.cp_subssup.on'):
				CM = "touch " + self.data_dir + '/.cp_subssup.on'
				os.system(CM)

		if self.cp_turkvod.value == False:
			if os.path.isfile(self.data_dir + '/.cp_turkvod.on'):
				os.remove(self.data_dir + '/.cp_turkvod.on')
		else:
			if not os.path.isfile(self.data_dir + '/.cp_turkvod.on'):
				CM = "touch " + self.data_dir + '/.cp_turkvod.on'
				os.system(CM)

		if self.cp_iptvplyr.value == False:
			if os.path.isfile(self.data_dir + '/.cp_iptvplyr.on'):
				os.remove(self.data_dir + '/.cp_iptvplyr.on')
		else:
			if not os.path.isfile(self.data_dir + '/.cp_iptvplyr.on'):
				CM = "touch " + self.data_dir + '/.cp_iptvplyr.on'
				os.system(CM)

		if self.cp_bologo.value == False:
			if os.path.isfile(self.data_dir + '/.cp_bologo.on'):
				os.remove(self.data_dir + '/.cp_bologo.on')
		else:
			if not os.path.isfile(self.data_dir + '/.cp_bologo.on'):
				CM = "touch " + self.data_dir + '/.cp_bologo.on'
				os.system(CM)

		if isTR() == "OK":
			if self.cp_trlang.value == False:
				if os.path.isfile(self.data_dir + '/.cp_trlang.on'):
					os.remove(self.data_dir + '/.cp_trlang.on')
			else:
				if not os.path.isfile(self.data_dir + '/.cp_trlang.on'):
					CM = "touch " + self.data_dir + '/.cp_trlang.on'
					os.system(CM)


		self.close()
