from __future__ import absolute_import

from Plugins.Plugin import PluginDescriptor

from .OMBManager import OMBManager
from .OMBManagerLocale import _

sIMG = "/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img"
try:
	from enigma import addFont
	font_osans = sIMG + "/osans.ttf"
	font_sagoe = sIMG + "/sagoe.ttf"
	addFont(font_osans, "osans", 100, True)
	addFont(font_sagoe, "sagoe", 100, True)
	addFont(font_sagoe, "buton", 90, True)
except:
	print ("[OMBE] > ERROR FONT ADDING")


def menu(menuid, **kwargs):
	if menuid == "mainmenu":
		return [("OMB Enhanced", OMBManager, "ombe_e2turk", 88)]
	return []

def Plugins(**kwargs):
	return [
		PluginDescriptor(
			name=_("OMB Enhanced"),
			description=_("OpenMultiBoot Manager"),
			icon='plugin.png',
			where=[PluginDescriptor.WHERE_EXTENSIONSMENU, PluginDescriptor.WHERE_PLUGINMENU],
			fnc=OMBManager
		),
		PluginDescriptor( name=_("OMB Enhanced"), description=_("OpenMultiBoot Manager"), where=PluginDescriptor.WHERE_MENU, fnc=menu
		)
	]
