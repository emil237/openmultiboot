from __future__ import print_function

import sys

KEYS_FNC_MAP = {
	'model': 'boxbranding.getMachineBuild()',
	'displaybrand': 'boxbranding.getMachineBrand()',
	'displaymodel': 'boxbranding.getMachineName()',
	'mtdkernel': 'boxbranding.getMachineMtdKernel()',
	'kernelfile': 'boxbranding.getMachineKernelFile()',
	'mtdrootfs': 'boxbranding.getMachineMtdRoot()',
	'rootfile': 'boxbranding.getMachineRootFile()',
	'mkubifs': 'boxbranding.getMachineMKUBIFS()',
	'ubinize': 'boxbranding.getMachineUBINIZE()',
	'brand': 'boxbranding.getBrandOEM()',
	'oe': 'boxbranding.getOEVersion()',
	'imageversion': 'boxbranding.getImageVersion()',
	'imagebuild': 'boxbranding.getImageBuild()',
	'distro': 'boxbranding.getImageDistro()',
	'imagedir': 'boxbranding.getImageFolder()',
	'imagefs': 'boxbranding.getImageFileSystem()'
}


def print_help():
	print('Syntax:')
	print(sys.argv[0] + ' enigma2_dir key')
	print('')
	print('Valid keys:')
	for key in KEYS_FNC_MAP.keys():
		print(' * ' + key)
	print(' * all')


if len(sys.argv) != 3:
	print_help()
else:
	sys.path.insert(0, sys.argv[1])
	try:
		import boxbranding
	except Exception as e:
		print ("OMBHELPER: Error:",e)
	if not sys.argv[2] in KEYS_FNC_MAP and sys.argv[2] != 'all':
		print_help()
	else:
		if sys.argv[2] == 'all':
			for key in KEYS_FNC_MAP.keys():
				print(key + ' = ' + eval(KEYS_FNC_MAP[key]))
		else:
			print(eval(KEYS_FNC_MAP[sys.argv[2]]))
