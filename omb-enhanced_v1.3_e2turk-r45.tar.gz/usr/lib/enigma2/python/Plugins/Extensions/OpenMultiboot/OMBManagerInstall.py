from __future__ import print_function
from __future__ import absolute_import

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox

from Components.ActionMap import ActionMap
from Components.Button import Button
from Components.Label import Label
from Components.Sources.List import List

from Tools.Directories import fileExists

from .OMBManagerCommon import OMB_MAIN_DIR, OMB_DATA_DIR, OMB_UPLOAD_DIR, OMB_TMP_DIR
from .OMBManagerLocale import _

from enigma import eTimer, getDesktop

def getDS():
	s = getDesktop(0).size()
	return (s.width(), s.height())
def isFHD():
	desktopSize = getDS()
	return desktopSize[0] == 1920
def isHD():
	desktopSize = getDS()
	return desktopSize[0] >= 1280 and desktopSize[0] < 1920
def isUHD():
	desktopSize = getDS()
	return desktopSize[0] >= 1920 and desktopSize[0] < 3840
def isTR():
	try:
		dil = ""
		ara = open("/etc/enigma2/settings", "r")
		bul = "config.osd.language=tr_TR"
		bak = ara.read().find(bul)
		if bak != -1:
			dil = "OK"
		else:
			dil = "NO"
		return dil
		ara.close()
	except:
		pass

import os
import glob
import struct

try:
	from boxbranding import *
	BRANDING = True
except:
	BRANDING = False

if BRANDING:
	OMB_GETBOXTYPE = getBoxType()
	OMB_GETBRANDOEM = getBrandOEM()
	OMB_GETIMAGEDISTRO = getImageDistro()
	OMB_GETIMAGEVERSION = getImageVersion()
	OMB_GETIMAGEFILESYSTEM = getImageFileSystem()
	OMB_GETIMAGEFOLDER = getImageFolder()
	OMB_GETMACHINEMTDKERNEL = getMachineMtdKernel()
	OMB_GETMACHINEKERNELFILE = getMachineKernelFile()
	OMB_GETMACHINEMTDROOT = getMachineMtdRoot()
	OMB_GETMACHINEROOTFILE = getMachineRootFile()
	OMB_GETMACHINEMKUBIFS = getMachineMKUBIFS()
	OMB_GETMACHINEUBINIZE = getMachineUBINIZE()
	OMB_GETMACHINEBUILD = getMachineBuild()
	OMB_GETMACHINEPROCMODEL = getMachineProcModel()
	OMB_GETMACHINEBRAND = getMachineBrand()
	OMB_GETMACHINENAME = getMachineName()
	OMB_GETOEVERSION = getOEVersion()
else:
	OMB_GETIMAGEFILESYSTEM = "tar.bz2"
	f = open("/proc/mounts", "r")
	for line in f:
		if line.find("rootfs") > -1:
			if line.find("ubi") > -1:
				OMB_GETIMAGEFILESYSTEM = "ubi"
				break
			if line.find("jffs2") > -1:
				OMB_GETIMAGEFILESYSTEM = "jffs2"
				break


OMB_DD_BIN = '/bin/dd'
OMB_CP_BIN = '/bin/cp'
OMB_RM_BIN = '/bin/rm'
OMB_TAR_BIN = '/bin/tar'
OMB_UBIATTACH_BIN = '/usr/sbin/ubiattach'
OMB_UBIDETACH_BIN = '/usr/sbin/ubidetach'
OMB_MOUNT_BIN = '/bin/mount'
OMB_UMOUNT_BIN = '/bin/umount'
OMB_MODPROBE_BIN = '/sbin/modprobe'
OMB_RMMOD_BIN = '/sbin/rmmod'
OMB_UNZIP_BIN = '/usr/bin/unzip'
OMB_LOSETUP_BIN = '/sbin/losetup'
OMB_ECHO_BIN = '/bin/echo'
OMB_MKNOD_BIN = '/bin/mknod'
OMB_UNJFFS2_BIN = '/usr/bin/unjffs2'


class OMBEnhancedInstall(Screen):
	if isFHD():
		skin = """
<screen position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#ff111111">
	<widget source="Title" render="Label" position="87,54" size="788,75" font="sagoe;51" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" noWrap="1" transparent="1" />
	<widget name="info" position="105,180" size="900,45" font="osans;30" halign="left" valign="center" foregroundColor="#00E2E2E2" backgroundColor="#1A0F0F0F" zPosition="1" transparent="1" />
	<eLabel position="105,240" size="1050,2" backgroundColor="#00E2E2E2" />
	<widget source="list" render="Listbox" position="105,270" size="1050,675" itemHeight="45" font="osans;30" scrollbarMode="showOnDemand" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" foregroundColorSelected="#00FFFFF" backgroundColorSelected="#1A27408B" scrollbarSliderBorderWidth="1" scrollbarWidth="8" scrollbarSliderForegroundColor="#00FFFFFF" scrollbarSliderBorderColor="#0027408B" enableWrapAround="1" transparent="1">
		<convert type="StringList" />
	</widget>
	<ePixmap position="1350,300" size="384,177" zPosition="5" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/ico_ombe_FHD.png" transparent="1" alphatest="blend" />
	<ePixmap position="1568,900" size="122,60" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/bt_ok_FHD.png" transparent="1" alphatest="blend" />
	<ePixmap position="1710,900" size="122,60" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/bt_exit_FHD.png" transparent="1" alphatest="blend" />
	<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/btc_red_FHD.png" position="53,953" size="45,60" alphatest="blend" />
	<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/btc_green_FHD.png" position="327,953" size="45,60" alphatest="blend" />
	<widget name="key_red" position="105,957" size="255,45" noWrap="1" zPosition="1" valign="center" font="buton;30" halign="left" backgroundColor="#1A0F0F0F" foregroundColor="#00FFFFFF" transparent="1" />
	<widget name="key_green" position="380,957" size="255,45" noWrap="1" zPosition="1" valign="center" font="buton;30" halign="left" backgroundColor="#1A0F0F0F" foregroundColor="#00FFFFFF" transparent="1" />
	<eLabel position="60,38" zPosition="-10" size="1133,975" backgroundColor="#1A0F0F0F" name="layer1" />
	<eLabel position="1193,90" zPosition="-10" size="668,870" backgroundColor="#1A27408B" name="layer2" />
	<widget source="global.CurrentTime" render="Label" position="978,45" size="210,90" font="sagoe;75" noWrap="1" halign="center" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Default</convert></widget>
	<widget source="global.CurrentTime" render="Label" position="768,45" size="210,41" font="sagoe;24" noWrap="1" halign="right" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Format:%A</convert></widget>
	<widget source="global.CurrentTime" render="Label" position="768,81" size="210,41" font="sagoe;24" noWrap="1" halign="right" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Format:%e. %b.</convert></widget>
</screen>
"""
	elif isUHD():
		skin = """
<screen position="0,0" size="3840,2160" flags="wfNoBorder" backgroundColor="#ff111111">
	<widget source="Title" render="Label" position="174,108" size="1575,150" font="sagoe;102" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" noWrap="1" transparent="1" />
	<widget name="info" position="210,360" size="1800,90" font="osans;60" halign="left" valign="center" foregroundColor="#00E2E2E2" backgroundColor="#1A0F0F0F" zPosition="1" transparent="1" />
	<eLabel position="210,480" size="2100,3" backgroundColor="#00E2E2E2" />
	<widget source="list" render="Listbox" position="210,540" size="2100,1350" itemHeight="90" font="osans;60" scrollbarMode="showOnDemand" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" foregroundColorSelected="#00FFFFF" backgroundColorSelected="#1A27408B" scrollbarSliderBorderWidth="1" scrollbarWidth="8" scrollbarSliderForegroundColor="#00FFFFFF" scrollbarSliderBorderColor="#0027408B" enableWrapAround="1" transparent="1">
		<convert type="StringList" />
	</widget>
	<ePixmap position="2700,600" size="768,354" zPosition="5" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/ico_ombe_UHD.png" transparent="1" alphatest="blend" />
	<ePixmap position="3135,1800" size="243,120" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/bt_ok_UHD.png" transparent="1" alphatest="blend" />
	<ePixmap position="3420,1800" size="243,120" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/bt_exit_UHD.png" transparent="1" alphatest="blend" />
	<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/btc_red_UHD.png" position="105,1905" size="90,120" alphatest="blend" />
	<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/btc_green_UHD.png" position="654,1905" size="90,120" alphatest="blend" />
	<widget name="key_red" position="210,1914" size="510,90" noWrap="1" zPosition="1" valign="center" font="buton;60" halign="left" backgroundColor="#1A0F0F0F" foregroundColor="#00FFFFFF" transparent="1" />
	<widget name="key_green" position="759,1914" size="510,90" noWrap="1" zPosition="1" valign="center" font="buton;60" halign="left" backgroundColor="#1A0F0F0F" foregroundColor="#00FFFFFF" transparent="1" />
	<eLabel position="120,75" zPosition="-10" size="2265,1950" backgroundColor="#1A0F0F0F" name="layer1" />
	<eLabel position="2385,180" zPosition="-10" size="1335,1740" backgroundColor="#1A27408B" name="layer2" />
	<widget source="global.CurrentTime" render="Label" position="1956,90" size="420,180" font="sagoe;150" noWrap="1" halign="center" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Default</convert></widget>
	<widget source="global.CurrentTime" render="Label" position="1536,90" size="420,81" font="sagoe;48" noWrap="1" halign="right" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Format:%A</convert></widget>
	<widget source="global.CurrentTime" render="Label" position="1536,162" size="420,81" font="sagoe;48" noWrap="1" halign="right" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Format:%e. %b.</convert></widget>
</screen>
"""
	else:
		skin = """
<screen position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="#ff111111">
	<widget source="Title" render="Label" position="58,36" size="525,50" font="sagoe;34" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" noWrap="1" transparent="1" />
	<widget name="info" position="70,120" size="600,30" font="osans;20" halign="left" valign="center" foregroundColor="#00E2E2E2" backgroundColor="#1A0F0F0F" zPosition="1" transparent="1" />
	<eLabel position="70,160" size="700,1" backgroundColor="#00E2E2E2" />
	<widget source="list" render="Listbox" position="70,180" size="700,450" itemHeight="30" font="osans;20" scrollbarMode="showOnDemand" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" foregroundColorSelected="#00FFFFF" backgroundColorSelected="#1A27408B" scrollbarSliderBorderWidth="1" scrollbarWidth="8" scrollbarSliderForegroundColor="#00FFFFFF" scrollbarSliderBorderColor="#0027408B" enableWrapAround="1" transparent="1">
		<convert type="StringList" />
	</widget>
	<ePixmap position="900,200" size="256,118" zPosition="5" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/ico_ombe.png" transparent="1" alphatest="blend" />
	<ePixmap position="1045,600" size="81,40" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/bt_ok.png" transparent="1" alphatest="blend" />
	<ePixmap position="1140,600" size="81,40" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/bt_exit.png" transparent="1" alphatest="blend" />
	<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/btc_red.png" position="35,635" size="30,40" alphatest="blend" />
	<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/btc_green.png" position="218,635" size="30,40" alphatest="blend" />
	<widget name="key_red" position="70,638" size="170,30" noWrap="1" zPosition="1" valign="center" font="buton;20" halign="left" backgroundColor="#1A0F0F0F" foregroundColor="#00FFFFFF" transparent="1" />
	<widget name="key_green" position="253,638" size="170,30" noWrap="1" zPosition="1" valign="center" font="buton;20" halign="left" backgroundColor="#1A0F0F0F" foregroundColor="#00FFFFFF" transparent="1" />
	<eLabel position="40,25" zPosition="-10" size="755,650" backgroundColor="#1A0F0F0F" name="layer1" />
	<eLabel position="795,60" zPosition="-10" size="445,580" backgroundColor="#1A27408B" name="layer2" />
	<widget source="global.CurrentTime" render="Label" position="652,30" size="140,60" font="sagoe;50" noWrap="1" halign="center" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Default</convert></widget>
	<widget source="global.CurrentTime" render="Label" position="512,30" size="140,27" font="sagoe;16" noWrap="1" halign="right" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Format:%A</convert></widget>
	<widget source="global.CurrentTime" render="Label" position="512,54" size="140,27" font="sagoe;16" noWrap="1" halign="right" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Format:%e. %b.</convert></widget>
</screen>
"""

	def __init__(self, session, mount_point, upload_list):
		Screen.__init__(self, session)
		self.setTitle(_('OMB Enhanced Installer'))
		self.session = session
		self.mount_point = mount_point
		self.esize = "128KiB"
		self.vid_offset = "2048"
		self.nandsim_parm = "first_id_byte=0x20 second_id_byte=0xac third_id_byte=0x00 fourth_id_byte=0x15"
		self['info'] = Label(_("Choose the image to install"))
		self["list"] = List(upload_list)
		self["key_red"] = Button(_('Cancel'))
		self["key_green"] = Button(_('Start Install'))
		self["actions"] = ActionMap(["SetupActions", "ColorActions"],
		{
			"cancel": self.keyCancel,
			"ok": self.keyInstall,
			"red": self.keyCancel,
			"green": self.keyInstall
		})

	def keyCancel(self):
		self.close()

	def keyInstall(self):
		self.selected_image = self["list"].getCurrent()
		if not self.selected_image:
			return

		self.messagebox = self.session.open(MessageBox, _('Please wait while installation is in progress.\nThis operation may take a while.'), MessageBox.TYPE_INFO, enable_input=False)
		self.timer = eTimer()
		self.timer.callback.append(self.installPrepare)
		self.timer.start(100)
		self.error_timer = eTimer()
		self.error_timer.callback.append(self.showErrorCallback)

	def showErrorCallback(self):
		self.error_timer.stop()
		self.session.open(MessageBox, self.error_message, type=MessageBox.TYPE_ERROR)
		self.close()

	def showError(self, error_message):
		self.messagebox.close()
		self.error_message = error_message
		self.error_timer.start(100)

	def guessIdentifierName(self, selected_image):
		selected_image = selected_image.replace(' ', '_')
		prefix = self.mount_point + '/' + OMB_DATA_DIR + '/'
		if not os.path.exists(prefix + selected_image):
			return selected_image

		count = 1
		while os.path.exists(prefix + selected_image + '_' + str(count)):
			count += 1

		return selected_image + '_' + str(count)

	def installPrepare(self):
		self.timer.stop()

		selected_image = self.selected_image
		selected_image_identifier = self.guessIdentifierName(selected_image)

		source_file = self.mount_point + '/' + OMB_UPLOAD_DIR + '/' + selected_image + '.zip'
		target_folder = self.mount_point + '/' + OMB_DATA_DIR + '/' + selected_image_identifier
		kernel_target_folder = self.mount_point + '/' + OMB_DATA_DIR + '/.kernels'
		kernel_target_file = kernel_target_folder + '/' + selected_image_identifier + '.bin'

		if not os.path.exists(OMB_MAIN_DIR):
			try:
				os.makedirs(OMB_MAIN_DIR)
			except OSError as exception:
				self.showError(_("Cannot create main folder %s") % OMB_MAIN_DIR)
				return

		if not os.path.exists(kernel_target_folder):
			try:
				os.makedirs(kernel_target_folder)
			except OSError as exception:
				self.showError(_("Cannot create kernel folder %s") % kernel_target_folder)
				return

		if os.path.exists(target_folder):
			self.showError(_("The folder %s already exist") % target_folder)
			return

		try:
			os.makedirs(target_folder)
		except OSError as exception:
			self.showError(_("Cannot create folder %s") % target_folder)
			return

		tmp_folder = self.mount_point + '/' + OMB_TMP_DIR
		if os.path.exists(tmp_folder):
			os.system(OMB_RM_BIN + ' -rf ' + tmp_folder)
		try:
			os.makedirs(tmp_folder)
			os.makedirs(tmp_folder + '/ubi')
			os.makedirs(tmp_folder + '/jffs2')
		except OSError as exception:
			self.showError(_("Cannot create folder %s") % tmp_folder)
			return

		if os.system(OMB_UNZIP_BIN + ' ' + source_file + ' -d ' + tmp_folder) != 0:
			self.showError(_("Cannot deflate image"))
			return

		nfifile = glob.glob('%s/*.nfi' % tmp_folder)
		if nfifile:
			if not self.extractImageNFI(nfifile[0], tmp_folder):
				self.showError(_("Cannot extract nfi image"))
				return
			else:
				os.system(OMB_RM_BIN + ' -f ' + source_file)
				self.afterInstallImage(target_folder)
				self.messagebox.close()
				self.close()
		elif self.installImage(tmp_folder, target_folder, kernel_target_file, tmp_folder):
			os.system(OMB_RM_BIN + ' -f ' + source_file)
			self.messagebox.close()
			self.close()

		os.system(OMB_RM_BIN + ' -rf ' + tmp_folder)

	def installImage(self, src_path, dst_path, kernel_dst_path, tmp_folder):
		if "ubi" in OMB_GETIMAGEFILESYSTEM:
			return self.installImageUBI(src_path, dst_path, kernel_dst_path, tmp_folder)
		elif "jffs2" in OMB_GETIMAGEFILESYSTEM:
			return self.installImageJFFS2(src_path, dst_path, kernel_dst_path, tmp_folder)
		elif "tar.bz2" in OMB_GETIMAGEFILESYSTEM:
			return self.installImageTARBZ2(src_path, dst_path, kernel_dst_path, tmp_folder)
		else:
			self.showError(_("Your STB doesn\'t seem supported"))
			return False

	def installImageTARBZ2(self, src_path, dst_path, kernel_dst_path, tmp_folder):
		base_path = src_path + '/' + OMB_GETIMAGEFOLDER
		rootfs_path = base_path + '/' + OMB_GETMACHINEROOTFILE
		kernel_path = base_path + '/' + OMB_GETMACHINEKERNELFILE

		if os.system(OMB_TAR_BIN + ' jxf %s -C %s' % (rootfs_path, dst_path)) != 0:
			self.showError(_("Error unpacking rootfs"))
			os.system("rm -rf %s" % (dst_path))
			return False

		if os.path.exists(dst_path + '/usr/bin/enigma2'):
			if os.system(OMB_CP_BIN + ' ' + kernel_path + ' ' + kernel_dst_path) != 0:
				self.showError(_("Error copying kernel"))
				os.system("rm -rf %s" % (dst_path))
				return False

		self.dirtyHack(dst_path)

		if os.path.exists("%s/usr/bin/enigma2" % (dst_path)):
			self.e2TURK_Boot(dst_path)

		return True

	def installImageJFFS2(self, src_path, dst_path, kernel_dst_path, tmp_folder):
		rc = True
		mtdfile = "/dev/mtdblock0"
		for i in range(0, 20):
			mtdfile = "/dev/mtdblock%d" % i
			if not os.path.exists(mtdfile):
				break

		base_path = src_path + '/' + OMB_GETIMAGEFOLDER
		rootfs_path = base_path + '/' + OMB_GETMACHINEROOTFILE
		kernel_path = base_path + '/' + OMB_GETMACHINEKERNELFILE
		jffs2_path = src_path + '/jffs2'

		if os.path.exists(OMB_UNJFFS2_BIN):
			if os.system("%s %s %s" % (OMB_UNJFFS2_BIN, rootfs_path, jffs2_path)) != 0:
				self.showError(_("Error unpacking rootfs"))
				os.system("rm -rf %s" % (dst_path))
				rc = False
			if os.path.exists(jffs2_path + '/usr/bin/enigma2'):
				if os.system(OMB_CP_BIN + ' -rp ' + jffs2_path + '/* ' + dst_path) != 0:
					self.showError(_("Error copying unpacked rootfs"))
					os.system("rm -rf %s" % (dst_path))
					rc = False
				if os.system(OMB_CP_BIN + ' ' + kernel_path + ' ' + kernel_dst_path) != 0:
					self.showError(_("Error copying kernel"))
					os.system("rm -rf %s" % (dst_path))
					rc = False
		else:
			os.system(OMB_MODPROBE_BIN + ' loop')
			os.system(OMB_MODPROBE_BIN + ' mtdblock')
			os.system(OMB_MODPROBE_BIN + ' block2mtd')
			os.system(OMB_MKNOD_BIN + ' ' + mtdfile + ' b 31 0')
			os.system(OMB_LOSETUP_BIN + ' /dev/loop0 ' + rootfs_path)
			os.system(OMB_ECHO_BIN + ' "/dev/loop0,%s" > /sys/module/block2mtd/parameters/block2mtd' % self.esize)
			os.system(OMB_MOUNT_BIN + ' -t jffs2 ' + mtdfile + ' ' + jffs2_path)

			if os.path.exists(jffs2_path + '/usr/bin/enigma2'):
				if os.system(OMB_CP_BIN + ' -rp ' + jffs2_path + '/* ' + dst_path) != 0:
					self.showError(_("Error copying unpacked rootfs"))
					os.system("rm -rf %s" % (dst_path))
					rc = False
				if os.system(OMB_CP_BIN + ' ' + kernel_path + ' ' + kernel_dst_path) != 0:
					self.showError(_("Error copying kernel"))
					os.system("rm -rf %s" % (dst_path))
					rc = False
			else:
				self.showError(_("Generic error in unpack process"))
				os.system("rm -rf %s" % (dst_path))
				rc = False

			os.system(OMB_UMOUNT_BIN + ' ' + jffs2_path)
			os.system(OMB_RMMOD_BIN + ' block2mtd')
			os.system(OMB_RMMOD_BIN + ' mtdblock')
			os.system(OMB_RMMOD_BIN + ' loop')

			if os.path.exists("%s/usr/bin/enigma2" % (dst_path)):
				self.e2TURK_Boot(dst_path)

		return rc

	def installImageUBI(self, src_path, dst_path, kernel_dst_path, tmp_folder):
		rc = True
		for i in range(0, 20):
			mtdfile = "/dev/mtd" + str(i)
			if os.path.exists(mtdfile) is False:
				break
		mtd = str(i)

		base_path = src_path + '/' + OMB_GETIMAGEFOLDER
		rootfs_path = base_path + '/' + OMB_GETMACHINEROOTFILE
		kernel_path = base_path + '/' + OMB_GETMACHINEKERNELFILE
		ubi_path = src_path + '/ubi'

		if OMB_GETMACHINEBUILD in ('inihdp'):
			if fileExists("/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/ubi_reader/ubi_extract_files.py"):
				ubifile = "/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/ubi_reader/ubi_extract_files.py"
			else:
				ubifile = "/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/ubi_reader/ubi_extract_files.pyo"
			cmd = "chmod 755 " + ubifile
			rc = os.system(cmd)
			cmd = "python " + ubifile + " " + rootfs_path + " -o " + ubi_path
			rc = os.system(cmd)
			os.system(OMB_CP_BIN + ' -rp ' + ubi_path + '/rootfs/* ' + dst_path)
			rc = os.system(cmd)
			cmd = ('chmod -R +x ' + dst_path)
			rc = os.system(cmd)
			cmd = 'rm -rf ' + ubi_path
			rc = os.system(cmd)
			os.system(OMB_CP_BIN + ' ' + kernel_path + ' ' + kernel_dst_path)
			self.dirtyHack(dst_path)
			return True

		virtual_mtd = tmp_folder + '/virtual_mtd'
		os.system(OMB_MODPROBE_BIN + ' nandsim cache_file=' + virtual_mtd + ' ' + self.nandsim_parm)
		if not os.path.exists('/dev/mtd' + mtd):
			os.system('rmmod nandsim')
			self.showError(_("Cannot create virtual MTD device"))
			return False

		if not os.path.exists('/dev/mtdblock' + mtd):
			os.system(OMB_DD_BIN + ' if=' + rootfs_path + ' of=/dev/mtd' + mtd + ' bs=2048')
		else:
			os.system(OMB_DD_BIN + ' if=' + rootfs_path + ' of=/dev/mtdblock' + mtd + ' bs=2048')

		os.system(OMB_UBIATTACH_BIN + ' /dev/ubi_ctrl -m ' + mtd + ' -O ' + self.vid_offset)
		os.system(OMB_MOUNT_BIN + ' -t ubifs ubi1_0 ' + ubi_path)

		if os.path.exists(ubi_path + '/usr/bin/enigma2'):
			if os.system(OMB_CP_BIN + ' -rp ' + ubi_path + '/* ' + dst_path) != 0:
				self.showError(_("Error copying unpacked rootfs"))
				os.system("rm -rf %s" % (dst_path))

				rc = False
			if os.system(OMB_CP_BIN + ' ' + kernel_path + ' ' + kernel_dst_path) != 0:
				self.showError(_("Error copying kernel"))
				os.system("rm -rf %s" % (dst_path))

				rc = False
		else:
			self.showError(_("Generic error in unpack process"))
			os.system("rm -rf %s" % (dst_path))

			rc = False

		os.system(OMB_UMOUNT_BIN + ' ' + ubi_path)
		os.system(OMB_UBIDETACH_BIN + ' -m ' + mtd)
		os.system(OMB_RMMOD_BIN + ' nandsim')

		self.dirtyHack(dst_path)

		if os.path.exists("%s/usr/bin/enigma2" % (dst_path)):
			self.e2TURK_Boot(dst_path)

		self.afterInstallImage(dst_path)

		return rc

	def extractImageNFI(self, nfifile, extractdir):
		nfidata = open(nfifile, 'r')
		header = nfidata.read(32)
		if header[:3] != 'NFI':
			print('Sorry, old NFI format deteced')
			nfidata.close()
			return False
		else:
			machine_type = header[4:4 + header[4:].find('\0')]
			if header[:4] == 'NFI3':
				machine_type = 'dm7020hdv2'

		print('Dreambox image type: %s' % machine_type)
		if machine_type == 'dm800' or machine_type == 'dm500hd' or machine_type == 'dm800se':
			self.esize = '0x4000,0x200'
			self.vid_offset = '512'
			bs = 512
			bso = 528
		elif machine_type == 'dm7020hd':
			self.esize = '0x40000,0x1000'
			self.vid_offset = '4096'
			self.nandsim_parm = 'first_id_byte=0xec second_id_byte=0xd5 third_id_byte=0x51 fourth_id_byte=0xa6'
			bs = 4096
			bso = 4224
		elif machine_type == 'dm8000':
			self.esize = '0x20000,0x800'
			self.vid_offset = '512'
			bs = 2048
			bso = 2112
		else: # dm7020hdv2, dm500hdv2, dm800sev2
			self.esize = '0x20000,0x800'
			self.vid_offset = '2048'
			self.nandsim_parm = 'first_id_byte=0xec second_id_byte=0xd3 third_id_byte=0x51 fourth_id_byte=0x95'
			bs = 2048
			bso = 2112

		(total_size, ) = struct.unpack('!L', nfidata.read(4))
		print('Total image size: %s Bytes' % total_size)

		part = 0
		while nfidata.tell() < total_size:
			(size, ) = struct.unpack('!L', nfidata.read(4))
			print('Processing partition # %d size %d Bytes' % (part, size))
			output_names = {2: 'kernel.bin', 3: 'rootfs.bin'}
			if part not in output_names:
				nfidata.seek(size, 1)
				print('Skipping %d data...' % size)
			else:
				print('Extracting %s with %d blocksize...' % (output_names[part], bs))
				output_filename = extractdir + '/' + output_names[part]
				if os.path.exists(output_filename):
					os.remove(output_filename)
				output = open(output_filename, 'wb')
				if part == 2:
					output.write(nfidata.read(size))
				else:
					for sector in range(size / bso):
						d = nfidata.read(bso)
						output.write(d[:bs])
				output.close()
			part = part + 1

		nfidata.close()
		print('Extracting %s to %s Finished!' % (nfifile, extractdir))

		return True

	def dirtyHack(self, dst_path):
		for pyver in [ "2.7", "3.8", "3.9", "3.10"]:
			if os.path.exists("/usr/lib/python" + pyver  + "/boxbranding.so"):
				if not os.path.exists("/usr/lib/python" + pyver  + "/boxbranding.so"):
					os.system("ln -s /usr/lib/enigma2/python/boxbranding.so /usr/lib/python" + pyver  + "/boxbranding.so")
				if os.path.exists(dst_path + "/usr/lib/python" + pyver  + "/boxbranding.py"):
					os.system("cp /usr/lib/enigma2/python/boxbranding.so " + dst_path + "/usr/lib/python" + pyver  + "/boxbranding.so")
					os.system("rm -f " + dst_path + "/usr/lib/python" + pyver  + "/boxbranding.py")
				if not os.path.exists(dst_path + "/usr/lib/python" + pyver  + "/subprocess.py"):
					os.system("cp /usr/lib/python" + pyver  + "/subprocess.py " + dst_path + "/usr/lib/python" + pyver  + "/subprocess.py")

		if os.path.exists(dst_path + "/sbin/open_multiboot"):
			os.system("rm -f " + dst_path + "/sbin/open_multiboot")
			os.system("rm -f " + dst_path + "/sbin/open-multiboot-branding-helper.py")
			os.system("rm -f " + dst_path + "/etc/ipk-postinsts/*-openmultiboot")
			os.system("ln -sfn /sbin/init.sysvinit " + dst_path + "/sbin/open_multiboot")

	def e2TURK_Boot(self, dst_path):
		DATA_PATH = self.mount_point + '/' + OMB_DATA_DIR + '/'

		def seeMi():
			try:
				OXS = ""
				FLE = open("/etc/opkg/all-feed.conf", "r")
				OAS = ["openatv", "pure2", "openspa", "openhdf", "egami", "opendroid", "opennfr", "openesi", "openld"]
				OPS = ["openpli", "openvision", "openvix", "openbh", "teamblue", "satdreamgr", "opentr", "openeight", "vti", "official", "hdmu"]
				for line in FLE:
					if any(word in line for word in OAS):
						OXS = "OAS"
					elif any(word in line for word in OPS):
						OXS = "OPS"
					else:
						OXS = "OEO"
				return OXS
				FLE.close()
			except:
				pass

		def seeTi():
			try:
				OXS = ""
				SRC = "%s/etc/opkg/all-feed.conf" % (dst_path)
				FLE = open(SRC, "r")
				OAS = ["openatv", "pure2", "openspa", "openhdf", "egami", "opendroid", "opennfr", "openesi", "openld"]
				OPS = ["openpli", "openvision", "openvix", "openbh", "teamblue", "satdreamgr", "opentr", "openeight", "vti", "official", "hdmu"]
				for line in FLE:
					if any(word in line for word in OAS):
						OXS = "OAS"
					elif any(word in line for word in OPS):
						OXS = "OPS"
					else:
						OXS = "OEO"
				return OXS
				FLE.close()
			except:
				pass

		if not os.path.exists("%s/etc/enigma2" % (dst_path)):
			CM = "mkdir -p %s/etc/enigma2" % (dst_path)
			RC = os.system(CM)

		if not os.path.exists("%s/etc/cron" % (dst_path)):
			CM = "mkdir -p %s/etc/cron" % (dst_path)
			RC = os.system(CM)
			if not os.path.exists("%s/etc/cron/crontabs" % (dst_path)):
				CM = "mkdir -p %s/etc/cron/crontabs" % (dst_path)
				RC = os.system(CM)

		if os.path.exists("/etc/enigma2/settingsP"):
			MiSET = "settingsP"
		else:
			MiSET = "settings"

		if os.path.exists("%s/etc/enigma2/settingsP" % (dst_path)):
			TiSET = "settingsP"
		else:
			TiSET = "settings"



		if os.path.exists("%s/usr/lib/python3.10" % (dst_path)):
			CM = "rm -rf %s/usr/lib/locale/tr_TR" % (dst_path)
			RC = os.system(CM)
			CM = "mkdir -p %s/usr/lib/locale/tr_TR" % (dst_path)
			RC = os.system(CM)

			if os.path.exists("%s/etc/openvision" % (dst_path)):
				CM = "cp -R %s/usr/lib/locale/en_GB/LC_CTYPE %s/usr/lib/locale/tr_TR" % (dst_path, dst_path)
				RC = os.system(CM)
			else:
				CM = "cp -R %s/usr/lib/locale/C.UTF-8/LC_CTYPE %s/usr/lib/locale/tr_TR" % (dst_path, dst_path)
				RC = os.system(CM)



		if os.path.exists("%s/etc/openvision" % (dst_path)):
			CM = "ln -s %s/usr/share/enigma2/bootlogo.mvi %s/usr/share/bootlogo.mvi" % (dst_path, dst_path)
			RC = os.system(CM)
			if os.path.exists("%s/usr/lib/python3.10" % (dst_path)):
				import re
				ov3O = dst_path
				ov3N = re.sub('/.*multiboot/', '', ov3O)
				CM = "sleep 5"
				RC = os.system(CM)
				CM = "echo 'openvision python3' >> " + DATA_PATH + ".label_" + ov3N
				RC = os.system(CM)


		EXTPP = "usr/lib/enigma2/python/Plugins/Extensions"
		SYSPP = "usr/lib/enigma2/python/Plugins/SystemPlugins"

		if os.path.exists("%s/etc/enigma2/%s" % (dst_path, TiSET)):
			CM = "rm -rf %s/etc/enigma2/%s" % (dst_path, TiSET)
			RC = os.system(CM)
			CM = "touch %s/etc/enigma2/%s" % (dst_path, TiSET)
			RC = os.system(CM)
		if not os.path.exists("%s/etc/enigma2/%s" % (dst_path, TiSET)):
			CM = "touch %s/etc/enigma2/%s" % (dst_path, TiSET)
			RC = os.system(CM)






		if os.path.isfile(DATA_PATH + ".cp_channels.on"):
			CM = "rm -rf %s/etc/defaultsat.tar.gz" % (dst_path)
			RC = os.system(CM)
			CM = "rm -rf %s/etc/enigma2/*.tv" % (dst_path)
			RC = os.system(CM)
			CM = "rm -rf %s/etc/enigma2/*.radio" % (dst_path)
			RC = os.system(CM)
			CM = "rm -rf %s/etc/enigma2/lamedb*" % (dst_path)
			RC = os.system(CM)
			CM = "cp -af /etc/enigma2/*.tv %s/etc/enigma2" % (dst_path)
			RC = os.system(CM)
			CM = "cp -af /etc/enigma2/*.radio %s/etc/enigma2" % (dst_path)
			RC = os.system(CM)
			CM = "cp -af /etc/enigma2/lamedb %s/etc/enigma2" % (dst_path)
			RC = os.system(CM)
			CM = "cp -af /etc/tuxbox/*.xml %s/etc/tuxbox" % (dst_path)
			RC = os.system(CM)
			CM = "echo 'config.misc.disable_background_scan=True' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
			RC = os.system(CM)
			CM = "grep config.tv /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			CM = "grep config.radio /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			CM = "grep config.servicelist /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			CM = "grep config.Nims /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			if seeMi() == "OAS" and seeTi() == "OPS" or os.path.exists("%s/%s/PKT" % (dst_path, EXTPP)):
				CM = "sed -e 's#config.Nims.\([0-9]\+\).dvbs.#config.Nims.\\1.#g' -i '%s/etc/enigma2/%s'" % (dst_path, TiSET)
				RC = os.system(CM)
			if seeMi() == "OPS" and seeTi() == "OAS":
				CM = "sed -e 's#config.Nims.\([0-9]\+\).#config.Nims.\\1.dvbs.#g' -i '%s/etc/enigma2/%s'" % (dst_path, TiSET)
				RC = os.system(CM)


		if os.path.isfile(DATA_PATH + ".cp_settings.on"):
			CM = "echo 'config.misc.firstrun=False' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
			RC = os.system(CM)
			CM = "echo 'config.misc.videowizardenabled=False' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
			RC = os.system(CM)
			CM = "echo 'config.misc.languageselected=False' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
			RC = os.system(CM)
			CM = "echo 'config.misc.initialchannelselection=False' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
			RC = os.system(CM)
			CM = "echo 'config.misc.do_overscanwizard=False' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
			RC = os.system(CM)

			CM = "grep config.av /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			if seeMi() == "OAS" and seeTi() == "OPS" or not os.path.exists("%s/%s/OBH" % (dst_path, SYSPP)) or not os.path.exists("%s/%s/ViX" % (dst_path, SYSPP)):
				CM = "sed -e 's#config.av.videomode.HDMI#config.av.videomode.DVI#g' -i '%s/etc/enigma2/%s'" % (dst_path, TiSET)
				RC = os.system(CM)
				CM = "echo 'config.av.videoport=DVI' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
				RC = os.system(CM)
			if seeMi() == "OPS" and seeTi() == "OAS" or os.path.exists("%s/%s/OBH" % (dst_path, SYSPP)) or os.path.exists("%s/%s/ViX" % (dst_path, SYSPP)):
				CM = "sed -e 's#config.av.videomode.DVI#config.av.videomode.HDMI#g' -i '%s/etc/enigma2/%s'" % (dst_path, TiSET)
				RC = os.system(CM)
				CM = "sed -e '/config.av.videoport=DVI/d' -i '%s/etc/enigma2/%s'" % (dst_path, TiSET)
				RC = os.system(CM)
			if seeMi() == "OPS":
				CM = "sed -e '/config.av.policy/d' -i '%s/etc/enigma2/%s'" % (dst_path, TiSET)
				RC = os.system(CM)
				CM = "echo 'config.av.policy_169=scale' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
				RC = os.system(CM)
				CM = "echo 'config.av.policy_43=scale' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
				RC = os.system(CM)

			CM = "grep config.audio /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			CM = "grep config.epg /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			if not os.path.exists("/etc/enigma2/e2TURK"):
				CM = "grep config.autolanguage /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
				RC = os.system(CM)

			CM = "grep config.usage /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			CM = "grep config.keyboard /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			CM = "grep config.plisettings /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			CM = "grep config.autotimer /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			CM = "grep config.transcodingsetup /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			CM = "grep config.streaming /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			CM = "grep config.subtitles /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			CM = "grep config.timezone /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			CM = "grep config.seek /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			CM = "grep config.mediaplayer /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			CM = "grep config.plugins.transcodingsetup /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			CM = "grep config.movielist /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			CM = "grep config.osd.alpha /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			CM = "grep config.osd.bright /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			CM = "grep config.osd.contrast /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			CM = "grep config.ntp /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			CM = "grep config.network /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			CM = "grep config.timeshift /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			CM = "grep config.oscaminfo /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			CM = "grep config.cccaminfo /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			CM = "grep config.tunermisc /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			CM = "grep config.workaround /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			CM = "grep config.pluginbrowser /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			CM = "grep config.fan /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)

			if seeTi() == "OPS":
				CM = "echo 'config.usage.setup_level=expert' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
				RC = os.system(CM)
				CM = "echo 'config.misc.RestartUI=true' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
				RC = os.system(CM)

			if os.path.exists("%s/usr/lib/enigma2/python/Plugins/PLi" % (dst_path)):
				CM = "echo 'config.misc.rcused=0' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
				RC = os.system(CM)

			if os.path.exists("%s/etc/openvision" % (dst_path)):
				print("VISION IMAGE")

			if os.path.exists("%s/etc/bhversion" % (dst_path)):
				CM = "sed -e 's#config.fans.\([0-9]\+\).pwm#config.plugins.manualfancontrols.pwmvalue#g' -i '%s/etc/enigma2/%s'" % (dst_path, TiSET)
				RC = os.system(CM)
				if isTR() == "OK":
					CM = "sed -e '/config.autolanguage/d' -i '%s/etc/enigma2/%s'" % (dst_path, TiSET)
					RC = os.system(CM)
					CM = "echo 'config.autolanguage.audio_autoselect1=tur Audio_TUR' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
					RC = os.system(CM)
					CM = "echo 'config.autolanguage.audio_autoselect2=eng qaa Englisch' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
					RC = os.system(CM)
					CM = "echo 'config.autolanguage.audio_autoselect3=orj dos ory org esl qaa und mis mul ORY ORJ Audio_ORJ' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
					RC = os.system(CM)
					CM = "echo 'config.autolanguage.audio_autoselect4=und' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
					RC = os.system(CM)
					CM = "echo 'config.autolanguage.audio_usecache=false' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
					RC = os.system(CM)
					CM = "echo 'config.autolanguage.subtitle_autoselect1=tur Audio_TUR' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
					RC = os.system(CM)
					CM = "echo 'config.autolanguage.subtitle_usecache=false' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
					RC = os.system(CM)

			if os.path.exists("%s/etc/vtiversion.info" % (dst_path)):
				CM = "echo 'config.usage.channelzap_w_bouquet=true' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
				RC = os.system(CM)
				CM = "echo 'config.usage.epg_default_view=singleepg' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
				RC = os.system(CM)

			if os.path.exists("%s/usr/lib/enigma2/python/Plugins/DemoPlugins" % (dst_path)) and not os.path.exists("%s/etc/bhversion" % (dst_path)):
				CM = "sed -e '/config.misc.RestartUI/d' -i '%s/etc/enigma2/%s'" % (dst_path, TiSET)
				RC = os.system(CM)
				CM = "echo 'config.usage.multibouquet=true' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
				RC = os.system(CM)

			if os.path.exists("%s/etc/vtiversion.info" % (dst_path)) or os.path.exists("%s/etc/bhversion" % (dst_path)) or os.path.exists("%s/usr/lib/enigma2/python/Plugins/DemoPlugins" % (dst_path)):
				CM = "sed -e '/config.av.policy/d' -i '%s/etc/enigma2/%s'" % (dst_path, TiSET)
				RC = os.system(CM)
				CM = "echo 'config.av.policy_169=scale' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
				RC = os.system(CM)
				CM = "echo 'config.av.policy_43=scale' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
				RC = os.system(CM)
				CM = "echo 'config.misc.defaultchosen=false' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
				RC = os.system(CM)
				CM = "echo 'config.misc.rcused=0' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
				RC = os.system(CM)
				CM = "sed -e 's#config.timezone.val=Istanbul#config.timezone.val=(GMT+03:00) Turkey#g' -i '%s/etc/enigma2/%s'" % (dst_path, TiSET)
				RC = os.system(CM)
				CM = "sed -e '/config.misc.initialchannelselection/d' -i '%s/etc/enigma2/%s'" % (dst_path, TiSET)
				RC = os.system(CM)
				CM = "echo 'config.misc.initialchannelselection=false' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
				RC = os.system(CM)
				CM = "sed -e '/config.misc.RestartUI/d' -i '%s/etc/enigma2/%s'" % (dst_path, TiSET)
				RC = os.system(CM)

			if os.path.exists("/etc/enigma2/e2TURK") and not os.path.exists("%s/usr/lib/enigma2/python/Plugins/DemoPlugins" % (dst_path)):
				CM = "echo 'config.autolanguage.audio_usecache=False' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
				RC = os.system(CM)
				CM = "echo 'config.autolanguage.subtitle_usecache=False' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
				RC = os.system(CM)
				CM = "echo 'config.autolanguage.audio_autoselect1=tur Audio_TUR' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
				RC = os.system(CM)
				CM = "echo 'config.autolanguage.subtitle_autoselect1=tur Audio_TUR' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
				RC = os.system(CM)
				CM = "echo 'config.autolanguage.audio_epglanguage=tur Audio_TUR' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
				RC = os.system(CM)
				CM = "echo 'config.autolanguage.audio_autoselect3=orj dos ory org esl qaa und mis mul ORY ORJ Audio_ORJ oth' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
				RC = os.system(CM)
				if os.path.exists("%s/etc/openvision" % (dst_path)) or os.path.exists("%s/usr/lib/enigma2/python/Plugins/PLi" % (dst_path)):
					CM = "echo 'config.autolanguage.audio_autoselect2=eng' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
					RC = os.system(CM)
					CM = "echo 'config.autolanguage.audio_epglanguage_alternative=eng' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
					RC = os.system(CM)
				if seeTi() == "OAS" or os.path.exists("%s/%s/OBH" % (dst_path, SYSPP)) or os.path.exists("%s/%s/ViX" % (dst_path, SYSPP)):
					CM = "echo 'config.autolanguage.audio_autoselect2=eng Englisch' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
					RC = os.system(CM)
					CM = "echo 'config.autolanguage.audio_autoselect4=und' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
					RC = os.system(CM)
					CM = "echo 'config.autolanguage.audio_epglanguage_alternative=eng Englisch' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
					RC = os.system(CM)
				if os.path.exists("/etc/enigma2/script"):
					CM = "cp -af /etc/enigma2/script %s/etc/enigma2" % (dst_path)
					RC = os.system(CM)
				if os.path.exists("/etc/cron/crontabs/root"):
					CM = "cp -af /etc/cron/crontabs/root %s/etc/cron/crontabs" % (dst_path)
					RC = os.system(CM)
				if os.path.exists("/etc/enigma2/KralTv.key"):
					CM = "cp -af /etc/enigma2/KralTv.key %s/etc/enigma2" % (dst_path)
					RC = os.system(CM)
				if os.path.exists("/etc/enigma2/iptvprov.list"):
					CM = "cp -af /etc/enigma2/iptvprov.list %s/etc/enigma2" % (dst_path)
					RC = os.system(CM)
				if os.path.exists("/etc/enigma2/tuxtublib"):
					CM = "cp -af /etc/enigma2/tuxtub* %s/etc/enigma2" % (dst_path)
					RC = os.system(CM)
				if os.path.exists("/etc/enigma2/epgpids.custom"):
					CM = "cp -af /etc/enigma2/epgpids.custom %s/etc/enigma2" % (dst_path)
					RC = os.system(CM)
				if os.path.exists("/etc/enigma2/epgimport.conf"):
					CM = "cp -af /etc/enigma2/epgimport.conf %s/etc/enigma2" % (dst_path)
					RC = os.system(CM)
				if os.path.exists("/etc/epgimport"):
					if not os.path.exists("%s/etc/epgimport" % (dst_path)):
						CM = "mkdir -p %s/etc/epgimport" % (dst_path)
						RC = os.system(CM)
					CM = "cp -af /etc/epgimport/*.* %s/etc/epgimport" % (dst_path)
					RC = os.system(CM)


		if os.path.isfile(DATA_PATH + ".cp_network.on"):
			if os.path.exists("/etc/vtiversion.info") or os.path.exists("%s/etc/vtiversion.info" % (dst_path)):
				print('network settings could not be copied, not recommended for this image')
			elif os.path.exists("/etc/bhversion") or os.path.exists("%s/etc/bhversion" % (dst_path)):
				print('network settings could not be copied, not recommended for this image')
			elif os.path.exists("/usr/lib/enigma2/python/Plugins/DemoPlugins") or os.path.exists("%s/usr/lib/enigma2/python/Plugins/DemoPlugins" % (dst_path)):
				print('network settings could not be copied, not recommended for this image')
			elif os.path.exists("/usr/lib/enigma2/python/Plugins/PLi") or os.path.exists("%s/usr/lib/enigma2/python/Plugins/PLi" % (dst_path)):
				print('copying network settings is currently not available')
			else:
				if os.path.exists("/etc/wpa_supplicant.wlan0.conf"):
					CM = "cp -af /etc/wpa_supplicant.wlan0.conf %s/etc/wpa_supplicant.wlan0.conf > /dev/null 2>&1" % (dst_path)
					RC = os.system(CM)
				if os.path.exists("/etc/network/interfaces"):
					CM = "cp -af /etc/network/interfaces %s/etc/network/interfaces > /dev/null 2>&1" % (dst_path)
					RC = os.system(CM)
				if os.path.exists("/etc/wpa_supplicant.conf"):
					CM = "cp -af /etc/wpa_supplicant.conf %s/etc/wpa_supplicant.conf > /dev/null 2>&1" % (dst_path)
					RC = os.system(CM)
				if os.path.exists("/etc/resolv.conf"):
					CM = "cp -af /etc/resolv.conf %s/etc/resolv.conf > /dev/null 2>&1" % (dst_path)
					RC = os.system(CM)
				if os.path.exists("/etc/wl.conf.wlan3"):
					CM = "cp -af /etc/wl.conf.wlan3 %s/etc/wl.conf.wlan3 > /dev/null 2>&1" % (dst_path)
					RC = os.system(CM)


		if os.path.isfile(DATA_PATH + ".cp_sysplug.on"):
			print("copying system plugins is currently not available")


		if os.path.isfile(DATA_PATH + ".cp_cimodul.on"):
			CM = "grep config.ci /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			CM = "echo 'config.misc.use_ci_assignment=True' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
			RC = os.system(CM)
			if os.path.exists("/etc/enigma2/ci0.xml") or os.path.exists("/etc/enigma2/ci1.xml"):
				CM = "cp -af /etc/enigma2/ci*.xml %s/etc/enigma2" % (dst_path)
				RC = os.system(CM)


		if os.path.isfile(DATA_PATH + ".cp_softcam.on"):
			if os.path.exists("/etc/CCcam.cfg"):
				CM = "cp -af /etc/CCcam.cfg %s/etc > /dev/null 2>&1" % (dst_path)
				RC = os.system(CM)
			if os.path.exists("/etc/tuxbox/config"):
				CM = "cp -af /etc/tuxbox/config %s/etc/tuxbox > /dev/null 2>&1" % (dst_path)
				RC = os.system(CM)
			if os.path.exists("/etc/init.d/softcam.oscam"):
				CM = "cp -af /etc/init.d/softcam.osca* %s/etc/init.d/ > /dev/null 2>&1" % (dst_path)
				RC = os.system(CM)
			if os.path.exists("/etc/init.d/softcam.OScam"):
				CM = "cp -af /etc/init.d/softcam.OSca* %s/etc/init.d/ > /dev/null 2>&1" % (dst_path)
				RC = os.system(CM)
				OsiPre = "rm -rf %s/etc/init.d/softcam > /dev/null 2>&1" % (dst_path) #rm -rf ekledik
				RC = os.system(OsiPre)
				OsiLnk = "cp -af /etc/init.d/softcam %s/etc/init.d/ > /dev/null 2>&1" % (dst_path)
				RC = os.system(OsiLnk)
				OSiDir = "mkdir -p %s/usr/keys/OScam > /dev/null 2>&1" % (dst_path)
				RC = os.system(OSiDir)
				OSiKey = "cp -af /usr/keys/OScam/* %s/usr/keys/OScam > /dev/null 2>&1" % (dst_path)
				RC = os.system(OSiKey)
			if os.path.exists("/etc/init.d/softcam.None"):
				CM = "cp -af /etc/init.d/softcam.None %s/etc/init.d > /dev/null 2>&1" % (dst_path)
				RC = os.system(CM)
			if os.path.exists("/etc/init.d/softcam.CCcam"):
				CM = "cp -af /etc/init.d/softcam.CCcam %s/etc/init.d > /dev/null 2>&1" % (dst_path)
				RC = os.system(CM)


		if os.path.isfile(DATA_PATH + ".cp_youtube.on"):
			CM = "grep config.plugins.YouTube /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)
			if os.path.exists("/etc/enigma2/YouTube.key"):
				CM = "cp -af /etc/enigma2/YouTube.key %s/etc/enigma2" % (dst_path)
				RC = os.system(CM)


		if os.path.isfile(DATA_PATH + ".cp_subssup.on"):
			CM = "grep config.plugins.subtitlesSupport /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)


		if os.path.isfile(DATA_PATH + ".cp_turkvod.on"):
			CM = "grep config.plugins.TURKVOD /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)


		if os.path.isfile(DATA_PATH + ".cp_iptvplyr.on"):
			CM = "grep config.plugins.iptvplayer /etc/enigma2/%s >> %s/etc/enigma2/%s" % (MiSET, dst_path, TiSET)
			RC = os.system(CM)


		if os.path.isfile(DATA_PATH + ".cp_bologo.on"):
			if isTR() == "OK":
				CM = "cp -af /%s/OpenMultiboot/img/ombe_bl_tr.mvi %s/usr/share/bootlogo.mvi > /dev/null 2>&1" % (EXTPP, dst_path)
				RC = os.system(CM)
			else:
				CM = "cp -af /%s/OpenMultiboot/img/ombe_bl_en.mvi %s/usr/share/bootlogo.mvi > /dev/null 2>&1" % (EXTPP, dst_path)
				RC = os.system(CM)


		if os.path.isfile(DATA_PATH + ".cp_trlang.on"):
			CM = "echo 'config.misc.country=TR' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
			RC = os.system(CM)
			CM = "echo 'config.misc.language=tr' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
			RC = os.system(CM)
			CM = "echo 'config.misc.locale=tr_TR' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
			RC = os.system(CM)
			CM = "echo 'config.osd.language=tr_TR' >> %s/etc/enigma2/%s" % (dst_path, TiSET)
			RC = os.system(CM)




	def afterInstallImage(self, dst_path):
		fix = False
		error = False
		file = dst_path + '/etc/init.d/volatile-media.sh'
		if os.path.exists(file):
			try:
				f = open(file, 'r')
				for line in f.readlines():
					if line.find('mountpoint -q "/media" || mount -t tmpfs -o size=64k tmpfs /media') > -1:
						fix = True
						break
				f.close()
			except:
				error = True
			if not fix and not error:
				import fileinput
				for line in fileinput.input(file, inplace=True):
					if 'mount -t tmpfs -o size=64k tmpfs /media' in line:
						print("mountpoint -q \"/media\" || mount -t tmpfs -o size=64k tmpfs /media")
					else:
						print(line.rstrip())
