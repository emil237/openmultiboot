from __future__ import absolute_import

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox

from Components.ActionMap import ActionMap
from Components.Label import Label

from .OMBManagerCommon import OMB_DATA_DIR, OMB_UPLOAD_DIR, OMB_TMP_DIR, OMB_MANAGER_VERION
from .OMBManagerLocale import _

from enigma import getDesktop

def getDS():
	s = getDesktop(0).size()
	return (s.width(), s.height())
def isFHD():
	desktopSize = getDS()
	return desktopSize[0] == 1920
def isHD():
	desktopSize = getDS()
	return desktopSize[0] >= 1280 and desktopSize[0] < 1920
def isUHD():
	desktopSize = getDS()
	return desktopSize[0] >= 1920 and desktopSize[0] < 3840

class OMBEnhancedAbout(Screen):
	if isFHD():
		skin = """
<screen position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#ff111111">
	<widget source="Title" render="Label" position="87,54" size="788,75" font="sagoe;51" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" noWrap="1" transparent="1" />
	<widget name="info" position="105,180" size="900,45" font="osans;30" halign="left" valign="center" foregroundColor="#00E2E2E2" backgroundColor="#1A0F0F0F" zPosition="1" transparent="1" />
	<eLabel position="105,240" size="1050,2" backgroundColor="#00E2E2E2" />
	<widget name="about" position="105,270" size="1050,675" itemHeight="45" font="osans;30" scrollbarMode="showOnDemand" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" foregroundColorSelected="#00FFFFF" backgroundColorSelected="#1A27408B" scrollbarSliderBorderWidth="1" scrollbarWidth="8" scrollbarSliderForegroundColor="#00FFFFFF" scrollbarSliderBorderColor="#0027408B" enableWrapAround="1" transparent="1" />
	<widget name="e2turk" position="105,474" size="900,45" font="osans;30" halign="left" valign="center" foregroundColor="#00A4C400" backgroundColor="#1A0F0F0F" zPosition="1" transparent="1" />
	<widget name="twiter" position="105,534" size="900,45" font="osans;30" halign="left" valign="center" foregroundColor="#00149BAF" backgroundColor="#1A0F0F0F" zPosition="1" transparent="1" />
	<widget name="thanks" position="105,678" size="900,45" font="osans;30" halign="left" valign="center" foregroundColor="#00F0A30A" backgroundColor="#1A0F0F0F" zPosition="1" transparent="1" />
	<widget name="author" position="105,735" size="1050,135" font="osans;30" halign="left" valign="center" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" zPosition="1" transparent="1" />
	<ePixmap position="1350,300" size="384,177" zPosition="5" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/ico_ombe_FHD.png" transparent="1" alphatest="blend" />
	<ePixmap position="1568,900" size="122,60" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/bt_ok_FHD.png" transparent="1" alphatest="blend" />
	<ePixmap position="1710,900" size="122,60" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/bt_exit_FHD.png" transparent="1" alphatest="blend" />
	<eLabel position="60,38" zPosition="-10" size="1133,975" backgroundColor="#1A0F0F0F" name="layer1" />
	<eLabel position="1193,90" zPosition="-10" size="668,870" backgroundColor="#1A27408B" name="layer2" />
	<widget source="global.CurrentTime" render="Label" position="978,45" size="210,90" font="sagoe;75" noWrap="1" halign="center" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Default</convert></widget>
	<widget source="global.CurrentTime" render="Label" position="768,45" size="210,41" font="sagoe;24" noWrap="1" halign="right" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Format:%A</convert></widget>
	<widget source="global.CurrentTime" render="Label" position="768,81" size="210,41" font="sagoe;24" noWrap="1" halign="right" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Format:%e. %b.</convert></widget>
</screen>
"""
	elif isUHD():
		skin = """
<screen position="0,0" size="3840,2160" flags="wfNoBorder" backgroundColor="#ff111111">
	<widget source="Title" render="Label" position="174,108" size="1575,150" font="sagoe;102" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" noWrap="1" transparent="1" />
	<widget name="info" position="210,360" size="1800,90" font="osans;60" halign="left" valign="center" foregroundColor="#00E2E2E2" backgroundColor="#1A0F0F0F" zPosition="1" transparent="1" />
	<eLabel position="210,480" size="2100,3" backgroundColor="#00E2E2E2" />
	<widget name="about" position="210,540" size="2100,1350" itemHeight="90" font="osans;60" scrollbarMode="showOnDemand" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" foregroundColorSelected="#00FFFFF" backgroundColorSelected="#1A27408B" scrollbarSliderBorderWidth="1" scrollbarWidth="8" scrollbarSliderForegroundColor="#00FFFFFF" scrollbarSliderBorderColor="#0027408B" enableWrapAround="1" transparent="1" />
	<widget name="e2turk" position="210,948" size="1800,90" font="osans;60" halign="left" valign="center" foregroundColor="#00A4C400" backgroundColor="#1A0F0F0F" zPosition="1" transparent="1" />
	<widget name="twiter" position="210,1068" size="1800,90" font="osans;60" halign="left" valign="center" foregroundColor="#00149BAF" backgroundColor="#1A0F0F0F" zPosition="1" transparent="1" />
	<widget name="thanks" position="210,1356" size="1800,90" font="osans;60" halign="left" valign="center" foregroundColor="#00F0A30A" backgroundColor="#1A0F0F0F" zPosition="1" transparent="1" />
	<widget name="author" position="210,1470" size="2100,270" font="osans;60" halign="left" valign="center" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" zPosition="1" transparent="1" />
	<ePixmap position="2700,600" size="768,354" zPosition="5" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/ico_ombe_UHD.png" transparent="1" alphatest="blend" />
	<ePixmap position="3135,1800" size="243,120" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/bt_ok_UHD.png" transparent="1" alphatest="blend" />
	<ePixmap position="3420,1800" size="243,120" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/bt_exit_UHD.png" transparent="1" alphatest="blend" />
	<eLabel position="120,75" zPosition="-10" size="2265,1950" backgroundColor="#1A0F0F0F" name="layer1" />
	<eLabel position="2385,180" zPosition="-10" size="1335,1740" backgroundColor="#1A27408B" name="layer2" />
	<widget source="global.CurrentTime" render="Label" position="1956,90" size="420,180" font="sagoe;150" noWrap="1" halign="center" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Default</convert></widget>
	<widget source="global.CurrentTime" render="Label" position="1536,90" size="420,81" font="sagoe;48" noWrap="1" halign="right" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Format:%A</convert></widget>
	<widget source="global.CurrentTime" render="Label" position="1536,162" size="420,81" font="sagoe;48" noWrap="1" halign="right" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Format:%e. %b.</convert></widget>
</screen>
"""
	else:
		skin = """
<screen position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="#ff111111">
	<widget source="Title" render="Label" position="58,36" size="525,50" font="sagoe;34" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" noWrap="1" transparent="1" />
	<widget name="info" position="70,120" size="600,30" font="osans;20" halign="left" valign="center" foregroundColor="#00E2E2E2" backgroundColor="#1A0F0F0F" zPosition="1" transparent="1" />
	<eLabel position="70,160" size="700,1" backgroundColor="#00E2E2E2" />
	<widget name="about" position="70,180" size="700,450" itemHeight="30" font="osans;20" scrollbarMode="showOnDemand" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" foregroundColorSelected="#00FFFFF" backgroundColorSelected="#1A27408B" scrollbarSliderBorderWidth="1" scrollbarWidth="8" scrollbarSliderForegroundColor="#00FFFFFF" scrollbarSliderBorderColor="#0027408B" enableWrapAround="1" transparent="1" />
	<widget name="e2turk" position="70,316" size="600,30" font="osans;20" halign="left" valign="center" foregroundColor="#00A4C400" backgroundColor="#1A0F0F0F" zPosition="1" transparent="1" />
	<widget name="twiter" position="70,356" size="600,30" font="osans;20" halign="left" valign="center" foregroundColor="#00149BAF" backgroundColor="#1A0F0F0F" zPosition="1" transparent="1" />
	<widget name="thanks" position="70,452" size="600,30" font="osans;20" halign="left" valign="center" foregroundColor="#00F0A30A" backgroundColor="#1A0F0F0F" zPosition="1" transparent="1" />
	<widget name="author" position="70,490" size="700,90" font="osans;20" halign="left" valign="center" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" zPosition="1" transparent="1" />
	<ePixmap position="900,200" size="256,118" zPosition="5" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/ico_ombe.png" transparent="1" alphatest="blend" />
	<ePixmap position="1045,600" size="81,40" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/bt_ok.png" transparent="1" alphatest="blend" />
	<ePixmap position="1140,600" size="81,40" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenMultiboot/img/bt_exit.png" transparent="1" alphatest="blend" />
	<eLabel position="40,25" zPosition="-10" size="755,650" backgroundColor="#1A0F0F0F" name="layer1" />
	<eLabel position="795,60" zPosition="-10" size="445,580" backgroundColor="#1A27408B" name="layer2" />
	<widget source="global.CurrentTime" render="Label" position="652,30" size="140,60" font="sagoe;50" noWrap="1" halign="center" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Default</convert></widget>
	<widget source="global.CurrentTime" render="Label" position="512,30" size="140,27" font="sagoe;16" noWrap="1" halign="right" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Format:%A</convert></widget>
	<widget source="global.CurrentTime" render="Label" position="512,54" size="140,27" font="sagoe;16" noWrap="1" halign="right" valign="bottom" foregroundColor="#00FFFFFF" backgroundColor="#1A0F0F0F" transparent="1"><convert type="ClockToText">Format:%e. %b.</convert></widget>
</screen>
"""

	def __init__(self, session):
		Screen.__init__(self, session)
		self.setTitle(_('About OMB Enhanced'))
		self['info'] = Label("OpenMultiBoot Enhanced by e2TURK")
		about = "OpenMultiBoot Manager v" + OMB_MANAGER_VERION + "\n\n"
		about += "(c) 2014 Impex-Sat Gmbh & Co.KG - by Sandro Cavazzoni\n\n\n"
		self['about'] = Label(about)
		self['e2turk'] = Label("Enhanced Version by e2TURK")
		self['twiter'] = Label("https://twitter.com/e2TURK")
		self['thanks'] = Label(":: special thanks ::")
		author = "skaman, kajgan, atvcaptain, arn354, dpeddi, athoik, persianpros\n"
		author += "dima73, atvblack64, betacentauri, a4tech, thawtes and all testers !"
		self['author'] = Label(author)
		self["actions"] = ActionMap(["SetupActions"],
		{
			"cancel": self.keyCancel,
			"ok": self.keyCancel
		})

	def keyCancel(self):
		self.close()
